#include<iostream>
using namespace std;
int main()
{
  cout<<"This is Programming Exam. Have fun.\n";
}
