#ifndef __LIB_KERNEL_STDIO_H
#define __LIB_KERNEL_STDIO_H

void putbuf(const char*, size_t);

#endif /* lib/kernel/stdio.h */
