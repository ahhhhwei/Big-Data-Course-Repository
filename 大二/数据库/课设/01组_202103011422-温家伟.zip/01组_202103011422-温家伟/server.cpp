#include "cpp-httplib-v0.7.15/httplib.h"
#include <fstream>
#include <string>
#include <mysql/mysql.h>

const std::string host = "127.0.0.1";
const std::string user = "ahwei";
const std::string passwd = "Bit104-7274";
const std::string db = "daidaidaidai";
const int port = 3306;
std::string USERNAME;
using namespace std;
// 定义login函数，主页面的登录逻辑
void login(const std::string& username, const std::string& password, const std::string& identity, httplib::Response &res) {
    MYSQL *conn;
    MYSQL_RES *result;
    MYSQL_ROW row;
    const char *server = host.c_str();
    const char *usr = user.c_str();
    const char *pwd = passwd.c_str();
    const char *database = db.c_str();
    int p = port;

    // 初始化数据库连接
    conn = mysql_init(NULL);

    // 连接数据库
    if (!mysql_real_connect(conn, server, usr, pwd, database, p, NULL, 0)) {
        fprintf(stderr, "%s\n", mysql_error(conn));
        exit(1);
    }

    if (mysql_set_character_set(conn, "utf8mb4") != 0) {
            std::cout << mysql_error(conn) << std::endl;
            std::cerr << "字符集设置失败!\n";
            res.status = 500;
            res.set_content("字符集设置失败", "text/plain");
            mysql_close(conn);
            return;
    }
    std::string query;
    // 构建查询语句
    if(identity=="student")
    {
        query = "select cwwz_sname02, cwwz_spassword02 from cwwz_student02 where cwwz_sname02='"+username+"' and cwwz_spassword02='"+ password + "'";
    }
    else if(identity=="teacher")
    {
        query = "select cwwz_tname02, cwwz_tpassword02 from cwwz_teacher02 where cwwz_tname02='"+username+"' and cwwz_tpassword02='"+ password + "'";
    }
    else if(identity=="admin")
    {
        query = "select cwwz_ano02, cwwz_apassword02 from cwwz_admin02 where cwwz_ano02='"+username+"' and cwwz_apassword02='"+ password + "'";
    }
    else
    {
        ;
    }
    // 执行查询
    if (mysql_query(conn, query.c_str())) {
        fprintf(stderr, "%s\n", mysql_error(conn));
        exit(1);
    }
    std::cout<<query<<"\n";
    result = mysql_store_result(conn);
    if (result) {
        row = mysql_fetch_row(result);
        int r = mysql_num_rows(result);
        std::cout<<r<<"\n";
        if (r) {
            // 查询到匹配的记录，登录成功
            mysql_free_result(result);
            mysql_close(conn);
            if (identity == "student") {
                // 学生身份登录逻辑
                res.set_content("success", "text/plain");
                res.status = 200; // 200代表登录成功
                res.set_header("Location", "/student.html");

            } else if (identity == "teacher") {
                // 老师身份登录逻辑
                res.set_content("success", "text/plain");
                res.status = 200;
                res.set_header("Location", "/teacher.html");

            } else if (identity == "admin") {
                // 管理员身份登录逻辑
                res.set_content("success", "text/plain");
                res.status = 200;
                res.set_header("Location", "/admin.html");
            }
        } else {
            // 未查询到匹配的记录，登录失败
            mysql_free_result(result);
            mysql_close(conn);
            res.set_content("用户名或密码不正确", "text/plain");
        }
    }
}

int main() 
{
    httplib::Server svr;
    
    svr.Get("/", [&](const httplib::Request &req, httplib::Response &res) {
        // 打开index.html文件
        std::ifstream file("htdlmoban/index.html");

        if (file.is_open()) {
            std::string content((std::istreambuf_iterator<char>(file)), std::istreambuf_iterator<char>());
            res.set_header("Content-Type", "text/html");
            res.set_content(content, "text/html");
        } else {
            res.status = 404;
            res.set_content("File not found", "text/plain");
        }
    });

    svr.Get("/student.html", [&](const httplib::Request &req, httplib::Response &res) {
        // 打开student.html文件
        std::ifstream file("htdlmoban/student.html");

        if (file.is_open()) {
            std::string content((std::istreambuf_iterator<char>(file)), std::istreambuf_iterator<char>());
            res.set_header("Content-Type", "text/html");
            res.set_content(content, "text/html");
        } else {
            res.status = 404;
            res.set_content("File not found", "text/plain");
        }
    });

    svr.Get("/teacher.html", [&](const httplib::Request &req, httplib::Response &res) {
        // 打开teacher.html文件
        std::ifstream file("htdlmoban/teacher.html");

        if (file.is_open()) {
            std::string content((std::istreambuf_iterator<char>(file)), std::istreambuf_iterator<char>());
            res.set_header("Content-Type", "text/html");
            res.set_content(content, "text/html");
        } else {
            res.status = 404;
            res.set_content("File not found", "text/plain");
        }
    });

    svr.Get("/admin.html", [&](const httplib::Request &req, httplib::Response &res) {
        // 打开admin.html文件
        std::ifstream file("htdlmoban/admin.html");

        if (file.is_open()) {
            std::string content((std::istreambuf_iterator<char>(file)), std::istreambuf_iterator<char>());
            res.set_header("Content-Type", "text/html");
            res.set_content(content, "text/html");
        } else {
            res.status = 404;
            res.set_content("File not found", "text/plain");
        }
    });

    svr.Get("/fetch_data", [&](const httplib::Request &req, httplib::Response &res) {
        // 连接数据库
        MYSQL *conn;
        const char *server = host.c_str();
        const char *usr = user.c_str();
        const char *pwd = passwd.c_str();
        const char *database = db.c_str();
        int p = port;

        conn = mysql_init(NULL);
        if (!mysql_real_connect(conn, server, usr, pwd, database, p, NULL, 0)) {
            fprintf(stderr, "%s\n", mysql_error(conn));
            res.status = 500;
            res.set_content("无法连接到数据库", "text/plain");
            mysql_close(conn);
            return;
        }

        if (mysql_set_character_set(conn, "utf8mb4") != 0) {
            std::cout << mysql_error(conn) << std::endl;
            std::cerr << "字符集设置失败!\n";
            res.status = 500;
            res.set_content("字符集设置失败", "text/plain");
            mysql_close(conn);
            return;
        }
        
        // 执行数据库查询操作
        std::string query = "SELECT cwwz_sno02, cwwz_sname02, cwwz_ssex02, cwwz_sage02, cwwz_source02, cwwz_credits02 FROM cwwz_student02 where cwwz_sname02 ='"+USERNAME+"'";
        std::cout<<query<<"\n";
        if (mysql_query(conn, query.c_str()) != 0) {
            fprintf(stderr, "%s\n", mysql_error(conn));
            res.status = 500;
            res.set_content("数据库查询失败", "text/plain");
            mysql_close(conn);
            return;
        }

        MYSQL_RES *result = mysql_store_result(conn);
        if (result == NULL) {
            fprintf(stderr, "%s\n", mysql_error(conn));
            res.status = 500;
            res.set_content("查询结果为空", "text/plain");
            mysql_close(conn);
            return;
        }

        MYSQL_ROW row;
        std::string response; // 用于存储查询结果的字符串

        // 获取列信息
        MYSQL_FIELD *field;
        MYSQL_FIELD* result_metadata = mysql_fetch_fields(result); // 使用mysql_fetch_fields获取列信息
        int num_fields = mysql_num_fields(result);
        std::string arr[10] = {"学号", "姓名", "性别", "年龄", "生源所在地", "已修学分总数"};
        // 处理查询结果
        while ((row = mysql_fetch_row(result)) != NULL) {
            for (int i = 0; i < num_fields; i++) {
                field = &result_metadata[i];
                std::string column_name = field->name;
                std::string column_value = row[i] ? row[i] : "";

                // 拼接每个数据项的名称和值
                response += arr[i] + ": " + column_value + "\n";
            }

            response += "\n";
        }


        mysql_free_result(result); // 释放查询结果内存
        mysql_close(conn); // 关闭数据库连接


        // 返回查询结果字符串
        res.set_header("Content-Type", "text/plain");
        res.set_content(response, "text/plain");

    });


    svr.Get("/fetch_data1", [&](const httplib::Request &req, httplib::Response &res) {
    // 连接数据库
        MYSQL *conn;
        const char *server = host.c_str();
        const char *usr = user.c_str();
        const char *pwd = passwd.c_str();
        const char *database = db.c_str();
        int p = port;

        conn = mysql_init(NULL);
        if (!mysql_real_connect(conn, server, usr, pwd, database, p, NULL, 0)) {
            fprintf(stderr, "%s\n", mysql_error(conn));
            res.status = 500;
            res.set_content("无法连接到数据库", "text/plain");
            mysql_close(conn);
            return;
        }

        if (mysql_set_character_set(conn, "utf8mb4") != 0) {
            std::cout << mysql_error(conn) << std::endl;
            std::cerr << "字符集设置失败!\n";
            res.status = 500;
            res.set_content("字符集设置失败", "text/plain");
            mysql_close(conn);
            return;
        }
        
        // 执行数据库查询操作
        std::string query = "SELECT cc.cwwz_coname02, cc.cwwz_cono02, cc.cwwz_cocredit02, cc.cwwz_semester02 FROM cwwz_student02 s JOIN cwwz_choose_course02 cc ON s.cwwz_sno02 = cc.cwwz_sno02 WHERE s.cwwz_sname02 = '" + USERNAME + "'";



        std::cout<<query<<"\n";
        if (mysql_query(conn, query.c_str()) != 0) {
            fprintf(stderr, "%s\n", mysql_error(conn));
            res.status = 500;
            res.set_content("数据库查询失败", "text/plain");
            mysql_close(conn);
            return;
        }

        MYSQL_RES *result = mysql_store_result(conn);
        if (result == NULL) {
            fprintf(stderr, "%s\n", mysql_error(conn));
            res.status = 500;
            res.set_content("查询结果为空", "text/plain");
            mysql_close(conn);
            return;
        }

        MYSQL_ROW row;
        std::string response; // 用于存储查询结果的字符串

        // 获取列信息
        MYSQL_FIELD *field;
        MYSQL_FIELD* result_metadata = mysql_fetch_fields(result); // 使用mysql_fetch_fields获取列信息
        int num_fields = mysql_num_fields(result);
        std::string arr[10] = {"课程名称", "课程编号", "学分", "开课学期", "任课教师", "学时", "考核方式"};
        // 处理查询结果
        std::string temp;
        while ((row = mysql_fetch_row(result)) != NULL) {
            for (int i = 0; i < num_fields; i++) {
                field = &result_metadata[i];
                std::string column_name = field->name;
                std::string column_value = row[i] ? row[i] : "";

                // 拼接每个数据项的名称和值
                response += arr[i] + ": " + column_value;
                if(arr[i] == "学分")
                {
                    temp = to_string(16*stoi(column_value));
                }
                response += "\n ";
            }
            response += arr[5];
            response += ": ";
            response += temp;
            response += "\n";
            response += arr[6];
            response += ": ";
            response += "考试\n\n";
        }

        mysql_free_result(result); // 释放查询结果内存
        mysql_close(conn); // 关闭数据库连接


        // 返回查询结果字符串
        res.set_header("Content-Type", "text/plain");
        res.set_content(response, "text/plain");

    });


    svr.Get("/fetch_data2", [&](const httplib::Request &req, httplib::Response &res) {
    // 连接数据库
        MYSQL *conn;
        const char *server = host.c_str();
        const char *usr = user.c_str();
        const char *pwd = passwd.c_str();
        const char *database = db.c_str();
        int p = port;

        conn = mysql_init(NULL);
        if (!mysql_real_connect(conn, server, usr, pwd, database, p, NULL, 0)) {
            fprintf(stderr, "%s\n", mysql_error(conn));
            res.status = 500;
            res.set_content("无法连接到数据库", "text/plain");
            mysql_close(conn);
            return;
        }

        if (mysql_set_character_set(conn, "utf8mb4") != 0) {
            std::cout << mysql_error(conn) << std::endl;
            std::cerr << "字符集设置失败!\n";
            res.status = 500;
            res.set_content("字符集设置失败", "text/plain");
            mysql_close(conn);
            return;
        }
        
        // 执行数据库查询操作
        std::string query = "select cwwz_report02.cwwz_sno02,cwwz_report02. cwwz_semester02,cwwz_course02.cwwz_coname02,cwwz_report02.cwwz_grade02,cwwz_student02.cwwz_sname02 "
                            "from cwwz_report02,cwwz_course02,cwwz_student02 "
                            "where cwwz_report02.cwwz_cono02 = cwwz_course02.cwwz_cono02 and "
                            "cwwz_report02.cwwz_sno02 = cwwz_student02.cwwz_sno02 and cwwz_student02.cwwz_sname02 = '" + USERNAME + "'";
        std::cout<<query<<"\n";
        if (mysql_query(conn, query.c_str()) != 0) {
            fprintf(stderr, "%s\n", mysql_error(conn));
            res.status = 500;
            res.set_content("数据库查询失败", "text/plain");
            mysql_close(conn);
            return;
        }

        MYSQL_RES *result = mysql_store_result(conn);
        if (result == NULL) {
            fprintf(stderr, "%s\n", mysql_error(conn));
            res.status = 500;
            res.set_content("查询结果为空", "text/plain");
            mysql_close(conn);
            return;
        }

        MYSQL_ROW row;
        std::string response; // 用于存储查询结果的字符串

        // 获取列信息
        MYSQL_FIELD *field;
        MYSQL_FIELD* result_metadata = mysql_fetch_fields(result); // 使用mysql_fetch_fields获取列信息
        int num_fields = mysql_num_fields(result);

        std::string arr[10] = {"学号", "学期", "课程名称", "成绩", "任课老师"};
        // 处理查询结果
        while ((row = mysql_fetch_row(result)) != NULL) {
            for (int i = 0; i < num_fields; i++) {
                field = &result_metadata[i];
                std::string column_name = field->name;
                std::string column_value = row[i] ? row[i] : "";

                // 拼接每个数据项的名称和值
                response += arr[i] + ": " + column_value;

                if (i != num_fields - 1) {
                    response += "\n ";
                }
            }

            response += "\n\n";
        }

        mysql_free_result(result); // 释放查询结果内存
        mysql_close(conn); // 关闭数据库连接


        // 返回查询结果字符串
        res.set_header("Content-Type", "text/plain");
        res.set_content(response, "text/plain");

    });

    svr.Get("/fetch_data3", [&](const httplib::Request &req, httplib::Response &res) {
        // 连接数据库
            MYSQL *conn;
            const char *server = host.c_str();
            const char *usr = user.c_str();
            const char *pwd = passwd.c_str();
            const char *database = db.c_str();
            int p = port;

            conn = mysql_init(NULL);
            if (!mysql_real_connect(conn, server, usr, pwd, database, p, NULL, 0)) {
                fprintf(stderr, "%s\n", mysql_error(conn));
                res.status = 500;
                res.set_content("无法连接到数据库", "text/plain");
                mysql_close(conn);
                return;
            }

            if (mysql_set_character_set(conn, "utf8mb4") != 0) {
                std::cout << mysql_error(conn) << std::endl;
                std::cerr << "字符集设置失败!\n";
                res.status = 500;
                res.set_content("字符集设置失败", "text/plain");
                mysql_close(conn);
                return;
            }
            
            // 执行数据库查询操作
            std::string query = "SELECT cwwz_tno02, cwwz_tname02, cwwz_tsex02, cwwz_tage02, cwwz_title02, cwwz_phone02 FROM cwwz_teacher02 where cwwz_tname02='" + USERNAME + "'";
            std::cout<<query<<"\n";
            if (mysql_query(conn, query.c_str()) != 0) {
                fprintf(stderr, "%s\n", mysql_error(conn));
                res.status = 500;
                res.set_content("数据库查询失败", "text/plain");
                mysql_close(conn);
                return;
            }

            MYSQL_RES *result = mysql_store_result(conn);
            if (result == NULL) {
                fprintf(stderr, "%s\n", mysql_error(conn));
                res.status = 500;
                res.set_content("查询结果为空", "text/plain");
                mysql_close(conn);
                return;
            }

            MYSQL_ROW row;
            std::string response; // 用于存储查询结果的字符串

            // 获取列信息
            MYSQL_FIELD *field;
            MYSQL_FIELD* result_metadata = mysql_fetch_fields(result); // 使用mysql_fetch_fields获取列信息
            int num_fields = mysql_num_fields(result);

            std::string arr[10] = {"教师编号", "姓名", "性别", "年龄", "职称", "联系电话"};
            // 处理查询结果
            while ((row = mysql_fetch_row(result)) != NULL) {
                for (int i = 0; i < num_fields; i++) {
                    field = &result_metadata[i];
                    std::string column_name = field->name;
                    std::string column_value = row[i] ? row[i] : "";

                    // 拼接每个数据项的名称和值
                    response += arr[i] + ": " + column_value;

                    if (i != num_fields - 1) {
                        response += "\n ";
                    }
                }

                response += "\n\n";
            }

            mysql_free_result(result); // 释放查询结果内存
            mysql_close(conn); // 关闭数据库连接


            // 返回查询结果字符串
            res.set_header("Content-Type", "text/plain");
            res.set_content(response, "text/plain");

        });

    svr.Get("/fetch_data4", [&](const httplib::Request &req, httplib::Response &res) {
        // 连接数据库
            MYSQL *conn;
            const char *server = host.c_str();
            const char *usr = user.c_str();
            const char *pwd = passwd.c_str();
            const char *database = db.c_str();
            int p = port;

            conn = mysql_init(NULL);
            if (!mysql_real_connect(conn, server, usr, pwd, database, p, NULL, 0)) {
                fprintf(stderr, "%s\n", mysql_error(conn));
                res.status = 500;
                res.set_content("无法连接到数据库", "text/plain");
                mysql_close(conn);
                return;
            }

            if (mysql_set_character_set(conn, "utf8mb4") != 0) {
                std::cout << mysql_error(conn) << std::endl;
                std::cerr << "字符集设置失败!\n";
                res.status = 500;
                res.set_content("字符集设置失败", "text/plain");
                mysql_close(conn);
                return;
            }
            
            // 执行数据库查询操作
            std::string query = "select cwwz_cono02, cwwz_coname02, cwwz_cocredit02, cwwz_semester02 from cwwz_teach_course02, cwwz_teacher02 where cwwz_teacher02.cwwz_tno02 = cwwz_teach_course02.cwwz_tno02 and cwwz_tname02 = '" + USERNAME + "'";
            std::cout<<query<<"\n";
            if (mysql_query(conn, query.c_str()) != 0) {
                fprintf(stderr, "%s\n", mysql_error(conn));
                res.status = 500;
                res.set_content("数据库查询失败", "text/plain");
                mysql_close(conn);
                return;
            }

            MYSQL_RES *result = mysql_store_result(conn);
            if (result == NULL) {
                fprintf(stderr, "%s\n", mysql_error(conn));
                res.status = 500;
                res.set_content("查询结果为空", "text/plain");
                mysql_close(conn);
                return;
            }

            MYSQL_ROW row;
            std::string response; // 用于存储查询结果的字符串

            // 获取列信息
            MYSQL_FIELD *field;
            MYSQL_FIELD* result_metadata = mysql_fetch_fields(result); // 使用mysql_fetch_fields获取列信息
            int num_fields = mysql_num_fields(result);

            std::string arr[10] = {"课程编号", "课程名称", "学分", "学期"};
            // 处理查询结果
            while ((row = mysql_fetch_row(result)) != NULL) {
                for (int i = 0; i < num_fields; i++) {
                    field = &result_metadata[i];
                    std::string column_name = field->name;
                    std::string column_value = row[i] ? row[i] : "";

                    // 拼接每个数据项的名称和值
                    response += arr[i] + ": " + column_value;

                    if (i != num_fields - 1) {
                        response += "\n ";
                    }
                }

                response += "\n\n";
            }

            mysql_free_result(result); // 释放查询结果内存
            mysql_close(conn); // 关闭数据库连接


            // 返回查询结果字符串
            res.set_header("Content-Type", "text/plain");
            res.set_content(response, "text/plain");

        });




        svr.Get("/fetch_data7", [&](const httplib::Request &req, httplib::Response &res) {
        // 连接数据库
            MYSQL *conn;
            const char *server = host.c_str();
            const char *usr = user.c_str();
            const char *pwd = passwd.c_str();
            const char *database = db.c_str();
            int p = port;

            conn = mysql_init(NULL);
            if (!mysql_real_connect(conn, server, usr, pwd, database, p, NULL, 0)) {
                fprintf(stderr, "%s\n", mysql_error(conn));
                res.status = 500;
                res.set_content("无法连接到数据库", "text/plain");
                mysql_close(conn);
                return;
            }

            if (mysql_set_character_set(conn, "utf8mb4") != 0) {
                std::cout << mysql_error(conn) << std::endl;
                std::cerr << "字符集设置失败!\n";
                res.status = 500;
                res.set_content("字符集设置失败", "text/plain");
                mysql_close(conn);
                return;
            }
            
            // 执行数据库查询操作
            std::string query = "SELECT cwwz_tno02, cwwz_tname02, cwwz_tsex02, cwwz_tage02, cwwz_title02, cwwz_phone02 FROM cwwz_teacher02 where cwwz_tname02='" + USERNAME + "'";
            std::cout<<query<<"\n";
            if (mysql_query(conn, query.c_str()) != 0) {
                fprintf(stderr, "%s\n", mysql_error(conn));
                res.status = 500;
                res.set_content("数据库查询失败", "text/plain");
                mysql_close(conn);
                return;
            }

            MYSQL_RES *result = mysql_store_result(conn);
            if (result == NULL) {
                fprintf(stderr, "%s\n", mysql_error(conn));
                res.status = 500;
                res.set_content("查询结果为空", "text/plain");
                mysql_close(conn);
                return;
            }

            MYSQL_ROW row;
            std::string response; // 用于存储查询结果的字符串

            // 获取列信息
            MYSQL_FIELD *field;
            MYSQL_FIELD* result_metadata = mysql_fetch_fields(result); // 使用mysql_fetch_fields获取列信息
            int num_fields = mysql_num_fields(result);

            std::string arr[10] = {"教师编号", "姓名", "性别", "年龄", "职称", "联系电话"};
            // 处理查询结果
            while ((row = mysql_fetch_row(result)) != NULL) {
                for (int i = 0; i < num_fields; i++) {
                    field = &result_metadata[i];
                    std::string column_name = field->name;
                    std::string column_value = row[i] ? row[i] : "";

                    // 拼接每个数据项的名称和值
                    response += arr[i] + ": " + column_value;

                    if (i != num_fields - 1) {
                        response += "\n ";
                    }
                }

                response += "\n\n";
            }

            mysql_free_result(result); // 释放查询结果内存
            mysql_close(conn); // 关闭数据库连接


            // 返回查询结果字符串
            res.set_header("Content-Type", "text/plain");
            res.set_content(response, "text/plain");

        });

    svr.Get("/fetch_data_stu_cnt", [&](const httplib::Request &req, httplib::Response &res) {
        // 连接数据库
            MYSQL *conn;
            const char *server = host.c_str();
            const char *usr = user.c_str();
            const char *pwd = passwd.c_str();
            const char *database = db.c_str();
            int p = port;

            conn = mysql_init(NULL);
            if (!mysql_real_connect(conn, server, usr, pwd, database, p, NULL, 0)) {
                fprintf(stderr, "%s\n", mysql_error(conn));
                res.status = 500;
                res.set_content("无法连接到数据库", "text/plain");
                mysql_close(conn);
                return;
            }

            if (mysql_set_character_set(conn, "utf8mb4") != 0) {
                std::cout << mysql_error(conn) << std::endl;
                std::cerr << "字符集设置失败!\n";
                res.status = 500;
                res.set_content("字符集设置失败", "text/plain");
                mysql_close(conn);
                return;
            }
            
            // 执行数据库查询操作
            std::string query = "SELECT cwwz_source02 AS 地区, COUNT(*) AS 学生数 FROM cwwz_student02 GROUP BY cwwz_source02";
            std::cout<<query<<"\n";
            if (mysql_query(conn, query.c_str()) != 0) {
                fprintf(stderr, "%s\n", mysql_error(conn));
                res.status = 500;
                res.set_content("数据库查询失败", "text/plain");
                mysql_close(conn);
                return;
            }

            MYSQL_RES *result = mysql_store_result(conn);
            if (result == NULL) {
                fprintf(stderr, "%s\n", mysql_error(conn));
                res.status = 500;
                res.set_content("查询结果为空", "text/plain");
                mysql_close(conn);
                return;
            }

            MYSQL_ROW row;
            std::string response; // 用于存储查询结果的字符串

            // 获取列信息
            MYSQL_FIELD *field;
            MYSQL_FIELD* result_metadata = mysql_fetch_fields(result); // 使用mysql_fetch_fields获取列信息
            int num_fields = mysql_num_fields(result);

            // 处理查询结果
            while ((row = mysql_fetch_row(result)) != NULL) {
                response += row[0];
                response += " : ";
                response += row[1];
                response += "\n";
            }

            mysql_free_result(result); // 释放查询结果内存
            mysql_close(conn); // 关闭数据库连接


            // 返回查询结果字符串
            res.set_header("Content-Type", "text/plain");
            res.set_content(response, "text/plain");

        });
        


        svr.Get("/fetch_data2_grade_stats", [&](const httplib::Request &req, httplib::Response &res) {
        // 连接数据库
            MYSQL *conn;
            const char *server = host.c_str();
            const char *usr = user.c_str();
            const char *pwd = passwd.c_str();
            const char *database = db.c_str();
            int p = port;

            conn = mysql_init(NULL);
            if (!mysql_real_connect(conn, server, usr, pwd, database, p, NULL, 0)) {
                fprintf(stderr, "%s\n", mysql_error(conn));
                res.status = 500;
                res.set_content("无法连接到数据库", "text/plain");
                mysql_close(conn);
                return;
            }

            if (mysql_set_character_set(conn, "utf8mb4") != 0) {
                std::cout << mysql_error(conn) << std::endl;
                std::cerr << "字符集设置失败!\n";
                res.status = 500;
                res.set_content("字符集设置失败", "text/plain");
                mysql_close(conn);
                return;
            }
            
            // 执行数据库查询操作
            std::string query = "SELECT cwwz_semester02, COUNT(*) AS total_students, AVG(cwwz_grade02) AS average_grade FROM cwwz_course_score02 GROUP BY cwwz_semester02";
            std::cout<<query<<"\n";
            if (mysql_query(conn, query.c_str()) != 0) {
                fprintf(stderr, "%s\n", mysql_error(conn));
                res.status = 500;
                res.set_content("数据库查询失败", "text/plain");
                mysql_close(conn);
                return;
            }

            MYSQL_RES *result = mysql_store_result(conn);
            if (result == NULL) {
                fprintf(stderr, "%s\n", mysql_error(conn));
                res.status = 500;
                res.set_content("查询结果为空", "text/plain");
                mysql_close(conn);
                return;
            }

            MYSQL_ROW row;
            std::string response; // 用于存储查询结果的字符串

            // 获取列信息
            MYSQL_FIELD *field;
            MYSQL_FIELD* result_metadata = mysql_fetch_fields(result); // 使用mysql_fetch_fields获取列信息
            int num_fields = mysql_num_fields(result);

            std::string arr[10] = {"学期", "总人数", "平均分"};
            // 处理查询结果
            while ((row = mysql_fetch_row(result)) != NULL) {
                for (int i = 0; i < num_fields; i++) {
                    field = &result_metadata[i];
                    std::string column_name = field->name;
                    std::string column_value = row[i] ? row[i] : "";

                    // 拼接每个数据项的名称和值
                    response += arr[i] + ": " + column_value;

                    if (i != num_fields - 1) {
                        response += "\n ";
                    }
                }

                response += "\n\n";
            }

            mysql_free_result(result); // 释放查询结果内存
            mysql_close(conn); // 关闭数据库连接


            // 返回查询结果字符串
            res.set_header("Content-Type", "text/plain");
            res.set_content(response, "text/plain");

        });



    svr.Get("/fetch_data_rank_sort", [&](const httplib::Request &req, httplib::Response &res) {
        // 连接数据库
            MYSQL *conn;
            const char *server = host.c_str();
            const char *usr = user.c_str();
            const char *pwd = passwd.c_str();
            const char *database = db.c_str();
            int p = port;

            conn = mysql_init(NULL);
            if (!mysql_real_connect(conn, server, usr, pwd, database, p, NULL, 0)) {
                fprintf(stderr, "%s\n", mysql_error(conn));
                res.status = 500;
                res.set_content("无法连接到数据库", "text/plain");
                mysql_close(conn);
                return;
            }

            if (mysql_set_character_set(conn, "utf8mb4") != 0) {
                std::cout << mysql_error(conn) << std::endl;
                std::cerr << "字符集设置失败!\n";
                res.status = 500;
                res.set_content("字符集设置失败", "text/plain");
                mysql_close(conn);
                return;
            }
            
            // 执行数据库查询操作
            std::string query = "SELECT cwwz_student_semester_rank02.cwwz_sno02, LPAD(cwwz_sname02, 4, ' '), CAST(ROUND(cwwz_avg_grades02, 2) AS DECIMAL(4, 2)) FROM cwwz_student_semester_rank02, cwwz_student02 WHERE cwwz_student_semester_rank02.cwwz_sno02 = cwwz_student02.cwwz_sno02";

            std::cout<<query<<"\n";
            if (mysql_query(conn, query.c_str()) != 0) {
                fprintf(stderr, "%s\n", mysql_error(conn));
                res.status = 500;
                res.set_content("数据库查询失败", "text/plain");
                mysql_close(conn);
                return;
            }

            MYSQL_RES *result = mysql_store_result(conn);
            if (result == NULL) {
                fprintf(stderr, "%s\n", mysql_error(conn));
                res.status = 500;
                res.set_content("查询结果为空", "text/plain");
                mysql_close(conn);
                return;
            }

            MYSQL_ROW row;
            std::string response; // 用于存储查询结果的字符串

            // 获取列信息
            MYSQL_FIELD *field;
            MYSQL_FIELD* result_metadata = mysql_fetch_fields(result); // 使用mysql_fetch_fields获取列信息
            int num_fields = mysql_num_fields(result);

            std::string arr[10] = {"------学号------", "-姓名-", "绩点"};
            // 处理查询结果
            std::string separator = " | "; // 分隔符，用于分隔每个字段
            std::string header; // 表头字符串
            std::string line; // 分隔线字符串

            // 处理表头
            for (int i = 0; i < num_fields; i++) {
                header += arr[i] + separator; // 拼接每个字段名和分隔符
            }
            header += "\n"; // 换行
            
            // 处理分隔线
            //line = std::string(header.length(), '-'); // 生成与表头等长的横线
            //line += "\n"; // 换行

            response += line; // 添加分隔线到结果字符串
            response += header; // 添加表头到结果字符串
            response += line; // 添加分隔线到结果字符串

            // 遍历查询结果的每一行
            while ((row = mysql_fetch_row(result)) != NULL) {
                std::string row_str; // 存储每行数据的字符串

                // 处理每行数据
                for (int i = 0; i < num_fields; i++) {
                    row_str += row[i]; // 获取当前字段的值
                    row_str += separator; // 添加分隔符
                }
                row_str += "\n"; // 换行

                response += row_str; // 添加当前行数据到结果字符串
            }

            response += line; // 添加分隔线到结果字符串



            mysql_free_result(result); // 释放查询结果内存
            mysql_close(conn); // 关闭数据库连接

            cout << response <<endl;
            // 返回查询结果字符串
            res.set_header("Content-Type", "text/plain");
            res.set_content(response, "text/plain");

        });


        svr.Get("/fetch_data_course_avg", [&](const httplib::Request &req, httplib::Response &res) {
        // 连接数据库
            MYSQL *conn;
            const char *server = host.c_str();
            const char *usr = user.c_str();
            const char *pwd = passwd.c_str();
            const char *database = db.c_str();
            int p = port;

            conn = mysql_init(NULL);
            if (!mysql_real_connect(conn, server, usr, pwd, database, p, NULL, 0)) {
                fprintf(stderr, "%s\n", mysql_error(conn));
                res.status = 500;
                res.set_content("无法连接到数据库", "text/plain");
                mysql_close(conn);
                return;
            }

            if (mysql_set_character_set(conn, "utf8mb4") != 0) {
                std::cout << mysql_error(conn) << std::endl;
                std::cerr << "字符集设置失败!\n";
                res.status = 500;
                res.set_content("字符集设置失败", "text/plain");
                mysql_close(conn);
                return;
            }
            
            // 执行数据库查询操作
            std::string query = "SELECT cwwz_coname02, AVG(cwwz_grade02) AS average_grade FROM cwwz_course_score02 GROUP BY cwwz_coname02";
            std::cout<<query<<"\n";
            if (mysql_query(conn, query.c_str()) != 0) {
                fprintf(stderr, "%s\n", mysql_error(conn));
                res.status = 500;
                res.set_content("数据库查询失败", "text/plain");
                mysql_close(conn);
                return;
            }

            MYSQL_RES *result = mysql_store_result(conn);
            if (result == NULL) {
                fprintf(stderr, "%s\n", mysql_error(conn));
                res.status = 500;
                res.set_content("查询结果为空", "text/plain");
                mysql_close(conn);
                return;
            }

            MYSQL_ROW row;
            std::string response; // 用于存储查询结果的字符串

            // 获取列信息
            MYSQL_FIELD *field;
            MYSQL_FIELD* result_metadata = mysql_fetch_fields(result); // 使用mysql_fetch_fields获取列信息
            int num_fields = mysql_num_fields(result);

            std::string arr[10] = {"课程名", "平均分"};
            // 处理查询结果
            while ((row = mysql_fetch_row(result)) != NULL) {
                for (int i = 0; i < num_fields; i++) {
                    field = &result_metadata[i];
                    std::string column_name = field->name;
                    std::string column_value = row[i] ? row[i] : "";

                    // 拼接每个数据项的名称和值
                    response += arr[i] + ": " + column_value;

                    if (i != num_fields - 1) {
                        response += "\n ";
                    }
                }

                response += "\n\n";
            }

            mysql_free_result(result); // 释放查询结果内存
            mysql_close(conn); // 关闭数据库连接


            // 返回查询结果字符串
            res.set_header("Content-Type", "text/plain");
            res.set_content(response, "text/plain");

        });


    svr.Post("/login", [&](const httplib::Request &req, httplib::Response &res) {
        // 获取 username、password 和 identity 参数
        std::string username = req.get_param_value("username");
        USERNAME = username;
        std::string password = req.get_param_value("password");
        std::string identity = req.get_param_value("identity");
        if (username.empty() || password.empty() || identity.empty()) {
            res.set_content("用户名、密码或身份不能为空", "text/plain");
        } else {
            // 调用login函数进行数据库匹配
            login(username, password, identity, res);
        }
    });

    svr.Post("/fetch_data5", [&](const httplib::Request &req, httplib::Response &res) {
        // 获取请求主体内容
        std::string STUname = req.get_param_value("StudentName");
        cout << STUname <<endl;
        // 在这里进行处理和解析接收到的数据

        res.set_content("正在查询中...", "text/plain");
        // 连接数据库
            MYSQL *conn;
            const char *server = host.c_str();
            const char *usr = user.c_str();
            const char *pwd = passwd.c_str();
            const char *database = db.c_str();
            int p = port;

            conn = mysql_init(NULL);
            if (!mysql_real_connect(conn, server, usr, pwd, database, p, NULL, 0)) {
                fprintf(stderr, "%s\n", mysql_error(conn));
                res.status = 500;
                res.set_content("无法连接到数据库", "text/plain");
                mysql_close(conn);
                return;
            }

            if (mysql_set_character_set(conn, "utf8mb4") != 0) {
                std::cout << mysql_error(conn) << std::endl;
                std::cerr << "字符集设置失败!\n";
                res.status = 500;
                res.set_content("字符集设置失败", "text/plain");
                mysql_close(conn);
                return;
            }
            
            // 执行数据库查询操作
            std::string query = "SELECT s.cwwz_sname02 AS '学生姓名', "
                       "s.cwwz_sno02 AS '学号', "
                       "t.cwwz_semester02 AS '学期', "
                       "c.cwwz_coname02 AS '课程名称', "
                       "r.cwwz_grade02 AS '课程成绩', "
                       "te.cwwz_tname02 AS '任课老师' "
                       "FROM cwwz_student02 s "
                       "JOIN cwwz_report02 r ON s.cwwz_sno02 = r.cwwz_sno02 "
                       "JOIN cwwz_course02 c ON r.cwwz_cono02 = c.cwwz_cono02 "
                       "JOIN cwwz_teach02 t ON r.cwwz_cono02 = t.cwwz_cono02 "
                       "JOIN cwwz_teacher02 te ON t.cwwz_tno02 = te.cwwz_tno02 "
                       "WHERE s.cwwz_sname02 = '" + STUname + "' AND te.cwwz_tname02 = '" + USERNAME + "'";


            std::cout<<query<<"\n";
            if (mysql_query(conn, query.c_str()) != 0) {
                fprintf(stderr, "%s\n", mysql_error(conn));
                res.status = 500;
                res.set_content("数据库查询失败", "text/plain");
                mysql_close(conn);
                return;
            }

            MYSQL_RES *result = mysql_store_result(conn);
            if (result == NULL) {
                fprintf(stderr, "%s\n", mysql_error(conn));
                res.status = 500;
                res.set_content("查询结果为空", "text/plain");
                mysql_close(conn);
                return;
            }

            MYSQL_ROW row;
            std::string response; // 用于存储查询结果的字符串

            // 获取列信息
            MYSQL_FIELD *field;
            MYSQL_FIELD* result_metadata = mysql_fetch_fields(result); // 使用mysql_fetch_fields获取列信息
            int num_fields = mysql_num_fields(result);

            std::string arr[10] = {"学生姓名", "学号", "学期", "课程名称", "课程成绩", "任课老师"};
            // 处理查询结果
            while ((row = mysql_fetch_row(result)) != NULL) {
                for (int i = 0; i < num_fields; i++) {
                    field = &result_metadata[i];
                    std::string column_name = field->name;
                    std::string column_value = row[i] ? row[i] : "";

                    // 拼接每个数据项的名称和值
                    response += arr[i] + ": " + column_value;

                    if (i != num_fields - 1) {
                        response += "\n ";
                    }
                }

                response += "\n\n";
            }

            mysql_free_result(result); // 释放查询结果内存
            mysql_close(conn); // 关闭数据库连接


            // 返回查询结果字符串
            res.set_header("Content-Type", "text/plain");
            res.set_content(response, "text/plain");
    });

    svr.Post("/fetch_data6", [&](const httplib::Request &req, httplib::Response &res) {
        // 获取请求主体内容
        std::string STUname = req.get_param_value("StudentName");
        cout << STUname <<endl;
        // 在这里进行处理和解析接收到的数据

        res.set_content("正在查询中...", "text/plain");
        // 连接数据库
            MYSQL *conn;
            const char *server = host.c_str();
            const char *usr = user.c_str();
            const char *pwd = passwd.c_str();
            const char *database = db.c_str();
            int p = port;

            conn = mysql_init(NULL);
            if (!mysql_real_connect(conn, server, usr, pwd, database, p, NULL, 0)) {
                fprintf(stderr, "%s\n", mysql_error(conn));
                res.status = 500;
                res.set_content("无法连接到数据库", "text/plain");
                mysql_close(conn);
                return;
            }

            if (mysql_set_character_set(conn, "utf8mb4") != 0) {
                std::cout << mysql_error(conn) << std::endl;
                std::cerr << "字符集设置失败!\n";
                res.status = 500;
                res.set_content("字符集设置失败", "text/plain");
                mysql_close(conn);
                return;
            }
            
            // 执行数据库查询操作
            std::string query = "SELECT cwwz_sno02, cwwz_sname02, cwwz_ssex02, cwwz_sage02, cwwz_source02, cwwz_credits02 FROM cwwz_student02 where cwwz_sname02 ='" + STUname + "'";
            std::cout<<query<<"\n";
            if (mysql_query(conn, query.c_str()) != 0) {
                fprintf(stderr, "%s\n", mysql_error(conn));
                res.status = 500;
                res.set_content("数据库查询失败", "text/plain");
                mysql_close(conn);
                return;
            }

            MYSQL_RES *result = mysql_store_result(conn);
            if (result == NULL) {
                fprintf(stderr, "%s\n", mysql_error(conn));
                res.status = 500;
                res.set_content("查询结果为空", "text/plain");
                mysql_close(conn);
                return;
            }

            MYSQL_ROW row;
            std::string response; // 用于存储查询结果的字符串

            // 获取列信息
            MYSQL_FIELD *field;
            MYSQL_FIELD* result_metadata = mysql_fetch_fields(result); // 使用mysql_fetch_fields获取列信息
            int num_fields = mysql_num_fields(result);

            std::string arr[10] = {"学号", "姓名", "性别", "年龄", "生源所在地", "已修学分总数"};
            // 处理查询结果
            while ((row = mysql_fetch_row(result)) != NULL) {
                for (int i = 0; i < num_fields; i++) {
                    field = &result_metadata[i];
                    std::string column_name = field->name;
                    std::string column_value = row[i] ? row[i] : "";

                    // 拼接每个数据项的名称和值
                    response += arr[i] + ": " + column_value;

                    if (i != num_fields - 1) {
                        response += "\n ";
                    }
                }

                response += "\n\n";
            }

            mysql_free_result(result); // 释放查询结果内存
            mysql_close(conn); // 关闭数据库连接


            // 返回查询结果字符串
            res.set_header("Content-Type", "text/plain");
            res.set_content(response, "text/plain");
    });

    svr.Post("/fetchData5ClassCourse", [&](const httplib::Request &req, httplib::Response &res) {
        // 获取请求主体内容
        std::string STUname = req.get_param_value("StudentName");
        cout << STUname <<endl;
        // 在这里进行处理和解析接收到的数据

        res.set_content("正在查询中...", "text/plain");
        // 连接数据库
            MYSQL *conn;
            const char *server = host.c_str();
            const char *usr = user.c_str();
            const char *pwd = passwd.c_str();
            const char *database = db.c_str();
            int p = port;

            conn = mysql_init(NULL);
            if (!mysql_real_connect(conn, server, usr, pwd, database, p, NULL, 0)) {
                fprintf(stderr, "%s\n", mysql_error(conn));
                res.status = 500;
                res.set_content("无法连接到数据库", "text/plain");
                mysql_close(conn);
                return;
            }

            if (mysql_set_character_set(conn, "utf8mb4") != 0) {
                std::cout << mysql_error(conn) << std::endl;
                std::cerr << "字符集设置失败!\n";
                res.status = 500;
                res.set_content("字符集设置失败", "text/plain");
                mysql_close(conn);
                return;
            }
            
            // 执行数据库查询操作
            std::string query = "select cwwz_dept02.cwwz_dname02,cwwz_course02.cwwz_coname02 "
                                "from cwwz_dept02,cwwz_course02,cwwz_deptcourse02 "
                                "where cwwz_dept02.cwwz_dno02 = cwwz_deptcourse02.cwwz_dno02 and "
                                "cwwz_deptcourse02.cwwz_cono02 = cwwz_course02.cwwz_cono02 and cwwz_dept02.cwwz_dname02 = '数据科学与大数据技术'";
            std::cout<<query<<"\n";
            if (mysql_query(conn, query.c_str()) != 0) {
                fprintf(stderr, "%s\n", mysql_error(conn));
                res.status = 500;
                res.set_content("数据库查询失败", "text/plain");
                mysql_close(conn);
                return;
            }

            MYSQL_RES *result = mysql_store_result(conn);
            if (result == NULL) {
                fprintf(stderr, "%s\n", mysql_error(conn));
                res.status = 500;
                res.set_content("查询结果为空", "text/plain");
                mysql_close(conn);
                return;
            }

            MYSQL_ROW row;
            std::string response; // 用于存储查询结果的字符串

            // 获取列信息
            MYSQL_FIELD *field;
            MYSQL_FIELD* result_metadata = mysql_fetch_fields(result); // 使用mysql_fetch_fields获取列信息
            int num_fields = mysql_num_fields(result);

            std::string arr[10] = {"班级", "课程"};
            // 处理查询结果
            while ((row = mysql_fetch_row(result)) != NULL) {
                for (int i = 0; i < num_fields; i++) {
                    field = &result_metadata[i];
                    std::string column_name = field->name;
                    std::string column_value = row[i] ? row[i] : "";

                    // 拼接每个数据项的名称和值
                    response += arr[i] + ": " + column_value;

                    if (i != num_fields - 1) {
                        response += "\n ";
                    }
                }

                response += "\n\n";
            }

            mysql_free_result(result); // 释放查询结果内存
            mysql_close(conn); // 关闭数据库连接


            // 返回查询结果字符串
            res.set_header("Content-Type", "text/plain");
            res.set_content(response, "text/plain");
    });


    svr.Post("/update_grade", [&](const httplib::Request &req, httplib::Response &res) {
        // 获取请求主体内容
        std::string studentId = req.get_param_value("studentId");
        std::string courseName = req.get_param_value("courseName");
        std::string newGrade = req.get_param_value("newGrade");
        // 在这里进行处理和解析接收到的数据

        res.set_content("正在查询中...", "text/plain");
        // 连接数据库
            MYSQL *conn;
            const char *server = host.c_str();
            const char *usr = user.c_str();
            const char *pwd = passwd.c_str();
            const char *database = db.c_str();
            int p = port;

            conn = mysql_init(NULL);
            if (!mysql_real_connect(conn, server, usr, pwd, database, p, NULL, 0)) {
                fprintf(stderr, "%s\n", mysql_error(conn));
                res.status = 500;
                res.set_content("无法连接到数据库", "text/plain");
                mysql_close(conn);
                return;
            }

            if (mysql_set_character_set(conn, "utf8mb4") != 0) {
                std::cout << mysql_error(conn) << std::endl;
                std::cerr << "字符集设置失败!\n";
                res.status = 500;
                res.set_content("字符集设置失败", "text/plain");
                mysql_close(conn);
                return;
            }
            
            // 执行数据库查询操作
            std::string query = "UPDATE cwwz_course_score02 SET cwwz_grade02 = " + newGrade + " WHERE cwwz_sno02 = '" + studentId + "' AND cwwz_coname02 = '" + courseName + "'";
            std::cout<<query<<"\n";
            if (mysql_query(conn, query.c_str()) != 0) {
                fprintf(stderr, "%s\n", mysql_error(conn));
                res.status = 500;
                res.set_content("数据库查询失败", "text/plain");
                mysql_close(conn);
                return;
            }

            MYSQL_RES *result = mysql_store_result(conn);
            if (result == NULL) {
                fprintf(stderr, "%s\n", mysql_error(conn));
                res.status = 500;
                res.set_content("查询结果为空", "text/plain");
                mysql_close(conn);
                return;
            }

            MYSQL_ROW row;
            std::string response; // 用于存储查询结果的字符串

            response += "修改成功！";

            mysql_free_result(result); // 释放查询结果内存
            mysql_close(conn); // 关闭数据库连接


            // 返回查询结果字符串
            res.set_header("Content-Type", "text/plain");
            res.set_content(response, "text/plain");
    });


    svr.listen("0.0.0.0", 8555);

    return 0;
}
