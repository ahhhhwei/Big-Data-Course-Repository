--修改搜索路径
--SHOW SEARCH_PATH;
--DROP SCHEMA IF EXISTS zjutuser;
--CREATE SCHEMA zjutuser AUTHORIZATION zjutuser;
--SET SEARCH_PATH TO zjutuser, public;
--SHOW SEARCH_PATH;


DROP DATABASE IF EXISTS daidaidaidai;
CREATE DATABASE daidaidaidai;
USE daidaidaidai;


#删除表
DROP TABLE IF EXISTS cwwz_report02;
DROP TABLE IF EXISTS cwwz_deptcourse02;
DROP TABLE IF EXISTS cwwz_teach02;
DROP TABLE IF EXISTS cwwz_teacher02;
DROP TABLE IF EXISTS cwwz_course02;
DROP TABLE IF EXISTS cwwz_student02;
DROP TABLE IF EXISTS cwwz_class02;
DROP TABLE IF EXISTS cwwz_dept02;
DROP TABLE IF EXISTS cwwz_admin02;

#建立专业表
CREATE TABLE cwwz_dept02
(cwwz_dno02 VARCHAR(20),
 cwwz_dname02 VARCHAR(20),
 CONSTRAINT PK_dept PRIMARY KEY(cwwz_dno02)
);

#建立班级表
CREATE TABLE cwwz_class02
(cwwz_csno02 VARCHAR(20),
 cwwz_csname02 VARCHAR(20),
 cwwz_dno02 VARCHAR(20),
 CONSTRAINT PK_class PRIMARY KEY(cwwz_csno02),
 CONSTRAINT FK_dept_class FOREIGN KEY(cwwz_dno02) REFERENCES cwwz_dept02(cwwz_dno02)
);

#建立学生表
CREATE TABLE cwwz_student02
(cwwz_sno02 VARCHAR(12),
 cwwz_sname02 VARCHAR(20) NOT NULL,
 cwwz_ssex02 VARCHAR(2),
 cwwz_sage02 INT,
 cwwz_source02 VARCHAR(20),
 cwwz_credits02 INT,
 cwwz_startdate02 DATE,
 cwwz_csno02 VARCHAR(20),
 cwwz_dno02 VARCHAR(20),
 cwwz_spassword02 VARCHAR(20) NOT NULL,
 CONSTRAINT PK_student PRIMARY KEY(cwwz_sno02),
 CONSTRAINT FK_student_class FOREIGN KEY(cwwz_csno02) REFERENCES cwwz_class02(cwwz_csno02),
 CONSTRAINT FK_student_dept FOREIGN KEY(cwwz_dno02) REFERENCES cwwz_dept02(cwwz_dno02),
 CONSTRAINT CK_student_sage CHECK(cwwz_sage02>=10),  /*年龄大于等于0*/
 CONSTRAINT CK_student_creditours CHECK(cwwz_credits02>=0)  /*已修学分大于等于0*/
);

#建立课程表
CREATE TABLE cwwz_course02
(cwwz_cono02 VARCHAR(20),
 cwwz_coname02 VARCHAR(100),
 cwwz_cocredit02 FLOAT,
 CONSTRAINT PK_course PRIMARY KEY(cwwz_cono02),
 CONSTRAINT CK_course_credit CHECK(cwwz_cocredit02>=0)/*学分大于等于0*/
);

#建立教师表
CREATE TABLE cwwz_teacher02
(cwwz_tno02 VARCHAR(12),
 cwwz_tname02 VARCHAR(20) NOT NULL,
 cwwz_tsex02 VARCHAR(2),
 cwwz_tage02 INT,
 cwwz_title02 VARCHAR(10),
 cwwz_phone02 VARCHAR(11),
 cwwz_tpassword02 VARCHAR(20) NOT NULL,
 CONSTRAINT PK_teacher PRIMARY KEY(cwwz_tno02),
 CONSTRAINT CK_teacher_age CHECK(cwwz_tage02>=10)/*年龄大于等于10*/
);

#建立教师授课表
CREATE TABLE cwwz_teach02
(cwwz_cono02 VARCHAR(20),
 cwwz_tno02 VARCHAR(20),
 cwwz_csno02 VARCHAR(20),
 cwwz_semester02 VARCHAR(20),
 CONSTRAINT PK_teach PRIMARY KEY(cwwz_tno02,cwwz_cono02,cwwz_csno02,cwwz_semester02),
 CONSTRAINT FK_teach_teacher FOREIGN KEY(cwwz_tno02) REFERENCES cwwz_teacher02(cwwz_tno02),
 CONSTRAINT FK_teach_course FOREIGN KEY(cwwz_cono02) REFERENCES cwwz_course02(cwwz_cono02),
 CONSTRAINT FK_teach_class FOREIGN KEY(cwwz_csno02) REFERENCES cwwz_class02(cwwz_csno02)
);

#建立开课表
CREATE TABLE cwwz_deptcourse02
(cwwz_cono02 VARCHAR(20),
 cwwz_dno02 VARCHAR(20),
 cwwz_optional02 VARCHAR(5),
 cwwz_semester02 VARCHAR(20),
 CONSTRAINT PK_deptcourse PRIMARY KEY(cwwz_cono02,cwwz_dno02,cwwz_semester02),
 CONSTRAINT FK_deptcourse_course FOREIGN KEY(cwwz_cono02) REFERENCES cwwz_course02(cwwz_cono02),
 CONSTRAINT FK_deptcourse_dept FOREIGN KEY(cwwz_dno02) REFERENCES cwwz_dept02(cwwz_dno02)
);

#建立成绩评分表
CREATE TABLE cwwz_report02
(cwwz_sno02 VARCHAR(12),
 cwwz_cono02 VARCHAR(20),
 cwwz_grade02 INT,
 cwwz_appraise02 INT,
 cwwz_semester02 VARCHAR(20),
 CONSTRAINT PK_report PRIMARY KEY(cwwz_sno02,cwwz_cono02,cwwz_semester02),
 CONSTRAINT FK_report_student FOREIGN KEY(cwwz_sno02) REFERENCES cwwz_student02(cwwz_sno02),
 CONSTRAINT FK_report_course FOREIGN KEY(cwwz_cono02) REFERENCES cwwz_course02(cwwz_cono02),
 CONSTRAINT CK_report_grade CHECK(cwwz_grade02>=0 AND cwwz_grade02<=100),/*成绩大于等于且小于等于1000*/
 CONSTRAINT CK_report_appraise CHECK(cwwz_appraise02>=0 AND cwwz_appraise02<=100)/*评分大于等于0且小于等于10*/
);





#管理员表
CREATE TABLE cwwz_admin02
(cwwz_ano02 VARCHAR(12),
 cwwz_apassword02 VARCHAR(20),
 CONSTRAINT PK_admin PRIMARY KEY(cwwz_ano02)
);

#插入数据
INSERT INTO cwwz_dept02
VALUES
  ('D01', '数据科学与大数据技术'),
  ('D02', '计算机科学技术'),
  ('D03', '软件工程'),
  ('D04', '数字媒体技术'),
  ('D05', '网络工程');

INSERT INTO cwwz_class02
VALUES
  ('CS01', '数据科学与大数据技术2101', 'D01'),
  ('CS02', '计算机科学技术2101', 'D02'),
  ('CS03', '软件工程2101', 'D03'),
  ('CS04', '软件工程2102', 'D03'),
  ('CS05', '软件工程2103', 'D03'),
  ('CS06', '数字媒体技术2101', 'D04'),
  ('CS07', '数字媒体技术2102', 'D04'),
  ('CS08', '网络工程2101', 'D05');




INSERT INTO cwwz_student02
VALUES
  ('202106060501', '鹿游原', '男', 20, '北京市海淀区', 106, '2021/9/1', 'CS01', 'D01', 'lyy123'),
  ('202106060502', '陈悠然', '男', 21, '浙江省杭州市', 95, '2021/9/1', 'CS01', 'D01', 'chenyr'),
  ('202106060507', '王翰林', '男', 18, '广东省广州市', 99, '2021/9/1', 'CS01', 'D01', 'WHL2021'),
  ('202106060523', '赵空之', '男', 19, '北京市海淀区', 97, '2021/9/1', 'CS01', 'D01', 'zzzzzz'),
  ('202106060519', '李尘希', '男', 21, '北京市海淀区', 97, '2021/9/1', 'CS01', 'D01', '男orning0221'),
  ('202106060506', '刘舞帆', '女', 20, '北京市海淀区', 96, '2021/9/1', 'CS01', 'D01', 'dancing111'),
  ('202106060601', '蓝琴', '女', 20, '北京市海淀区', 102, '2021/9/1', 'CS01', 'D01', 'loveCLE'),
  ('202106060612', '宋羽凡', '男', 20, '上海市徐汇区', 103, '2021/9/1', 'CS01', 'D01', '1q2w3e'),
  ('202106060605', '何洪云', '男', 20, '上海市徐汇区', 101, '2021/9/1', 'CS02', 'D02', 'qwerty'),
  ('202106060621', '周颖瑶', '女', 20, '上海市徐汇区', 100, '2021/9/1', 'CS02', 'D02', '4r5t6y'),
  ('202106060613', '钱敏', '女', 19, '福建省厦门市', 100, '2021/9/1', 'CS02', 'D02', '123456'),
  ('202106060623', '孙婉清', '女', 21, '广东省广州市', 101, '2021/9/1', 'CS02', 'D02', '123456'),
  ('202106060616', '钱右黄', '男', 20, '河北省唐山市', 102, '2021/9/1', 'CS02', 'D02', 'yellow_right'),
  ('202106060604', '林兰楚', '男', 20, '山西省太原市', 103, '2021/9/1', 'CS02', 'D02', '000000'),
  ('202106060701', '李虹汝', '女', 20, '山西省太原市', 101, '2021/9/1', 'CS02', 'D02', '000000'),
  ('202106060711', '吴白丁', '男', 19, '北京市海淀区', 105, '2021/9/1', 'CS02', 'D02', '000000'),
  ('202106060721', '郑苏芹', '女', 20, '北京市海淀区', 110, '2021/9/1', 'CS03', 'D03', '000000'),
  ('202106060705', '金景', '男', 20, '山西省太原市', 109, '2021/9/1', 'CS03', 'D03', '000000'),
  ('202106060726', '冯思朱', '男', 20, '山西省太原市', 112, '2021/9/1', 'CS03', 'D03', '000000'),
  ('202106060715', '陈峦尔', '女', 18, '浙江省杭州市', 95, '2021/9/1', 'CS03', 'D03', '000000'),
  ('202106060706', '卫安杜', '男', 20, '浙江省杭州市', 96, '2021/9/1', 'CS03', 'D03', '000000'),
  ('202106060708', '蒋南阳', '男', 20, '浙江省杭州市', 96, '2021/9/1', 'CS03', 'D03', '7u8i9o'),
  ('202106060718', '韩西蜀', '女', 20, '浙江省杭州市', 99, '2021/9/1', 'CS03', 'D03', 'azsxdc'),
  ('202106060201', '杨庆力', '男', 20, '山西省大同市', 91, '2021/9/1', 'CS03', 'D03', '000000'),
  ('202106060203', '朱念春', '女', 21, '山西省大同市', 85, '2021/9/1', 'CS03', 'D03', 'znc456789'),
  ('202106060205', '许八灵', '男', 20, '山西省大同市', 96, '2021/9/1', 'CS03', 'D03', '8080'),
  ('202106060206', '吕月明', '男', 20, '山西省大同市', 97, '2021/9/1', 'CS04', 'D03', '男oonlight2003'),
  ('202106060208', '张同和', '男', 20, '北京市海淀区', 112, '2021/9/1', 'CS04', 'D03', '000000'),
  ('202106060211', '赵居兴', '女', 18, '北京市海淀区', 106, '2021/9/1', 'CS04', 'D03', 'l男knjb'),
  ('202106060212', '赵九秩', '男', 19, '山西省大同市', 104, '2021/9/1', 'CS04', 'D03', '1qa2ws'),
  ('202106060215', '崔洞庭', '男', 20, '山西省大同市', 105, '2021/9/1', 'CS04', 'D03', '000000'),
  ('202106060221', '乐商商', '女', 20, '北京市海淀区', 106, '2021/9/1', 'CS04', 'D03', '000000'),
  ('202106060231', '高溪音', '女', 19, '山东省济南市', 106, '2021/9/1', 'CS04', 'D03', '000000'),
  ('202106060301', '曹泓', '男', 20, '山东省济南市', 107, '2021/9/1', 'CS04', 'D03', '000000'),
  ('202106060302', '袁迎泽', '男', 19, '山东省济南市', 106, '2021/9/1', 'CS04', 'D03', '000000'),
  ('202106060305', '于雨竹', '女', 20, '山东省济南市', 108, '2021/9/1', 'CS04', 'D03', '000000'),
  ('202106060307', '唐玄参', '男', 19, '山东省济南市', 106, '2021/9/1', 'CS04', 'D03', '000000'),
  ('202106060309', '董白薇', '女', 19, '山东省济南市', 109, '2021/9/1', 'CS04', 'D03', '000000'),
  ('202106060311', '夏潜', '男', 19, '北京市海淀区', 106, '2021/9/1', 'CS05', 'D03', '000000'),
  ('202106060313', '薛练海', '男', 19, '北京市海淀区', 110, '2021/9/1', 'CS05', 'D03', '000000'),
  ('202106060315', '姚半夏', '男', 19, '北京市东城区', 110, '2021/9/1', 'CS05', 'D03', '000000'),
  ('202106060319', '彭木', '男', 19, '山东省济南市', 95, '2021/9/1', 'CS05', 'D03', '000000'),
  ('202106060332', '曾伟', '男', 20, '江苏省南京市', 96, '2021/9/1', 'CS05', 'D03', '000000'),
  ('202106060331', '汪芊芊', '女', 21, '北京市海淀区', 96, '2021/9/1', 'CS05', 'D03', '000000'),
  ('202106060321', '江长真', '男', 20, '江苏省南京市', 97, '2021/9/1', 'CS05', 'D03', '000000'),
  ('202106060401', '苏送虎', '男', 20, '北京市海淀区', 86, '2021/9/1', 'CS05', 'D03', '000000'),
  ('202106060405', '陆绫紫', '女', 21, '江苏省南京市', 98, '2021/9/1', 'CS05', 'D03', '000000'),
  ('202106060409', '贾穆', '男', 20, '北京市海淀区', 86, '2021/9/1', 'CS06', 'D04', '000000'),
  ('202106060415', '徐左马', '男', 20, '广东省广州市', 96, '2021/9/1', 'CS06', 'D04', '000000'),
  ('202106060419', '萧风笑', '男', 20, '广东省广州市', 95, '2021/9/1', 'CS06', 'D04', '000000'),
  ('202106060420', '魏皓', '男', 21, '北京市海淀区', 94, '2021/9/1', 'CS06', 'D04', '000000'),
  ('202106060421', '邓天集', '男', 20, '福建省厦门市', 93, '2021/9/1', 'CS06', 'D04', '000000'),
  ('202106060431', '阎杉', '男', 20, '福建省厦门市', 92, '2021/9/1', 'CS06', 'D04', '000000'),
  ('202106060414', '丁一极', '男', 21, '福建省厦门市', 99, '2021/9/1', 'CS06', 'D04', '000000'),
  ('202106060432', '温冬', '女', 20, '福建省厦门市', 101, '2021/9/1', 'CS06', 'D04', '000000'),
  ('202106060435', '杜芸', '女', 20, '北京市海淀区', 106, '2021/9/1', 'CS07', 'D04', '000000'),
  ('202106060901', '戴离离', '女', 20, '北京市海淀区', 100, '2021/9/1', 'CS07', 'D04', '000000'),
  ('202106060908', '毛通书', '男', 21, '福建省厦门市', 100, '2021/9/1', 'CS07', 'D04', '000000'),
  ('202106060904', '钟家发', '男', 21, '北京市海淀区', 106, '2021/9/1', 'CS07', 'D04', '000000'),
  ('202106060911', '廖秉烛', '男', 21, '福建省厦门市', 102, '2021/9/1', 'CS07', 'D04', '000000'),
  ('202106060916', '田帛', '男', 21, '北京市海淀区', 103, '2021/9/1', 'CS07', 'D04', '000000'),
  ('202106060917', '任问天', '男', 20, '河北省唐山市', 105, '2021/9/1', 'CS07', 'D04', '000000'),
  ('202106060932', '姜九歌', '男', 20, '北京市海淀区', 105, '2021/9/1', 'CS07', 'D04', '000000'),
  ('202106060921', '范烨', '男', 18, '河北省唐山市', 105, '2021/9/1', 'CS07', 'D04', '000000'),
  ('202106060925', '方冰心', '女', 19, '河北省唐山市', 115, '2021/9/1', 'CS07', 'D04', '000000'),
  ('202106060929', '叶少科', '男', 20, '河北省唐山市', 112, '2021/9/1', 'CS07', 'D04', '000000'),
  ('202106061101', '蔡成州', '男', 20, '山西省太原市', 111, '2021/9/1', 'CS07', 'D04', '000000'),
  ('202106061103', '程月', '女', 20, '山西省太原市', 113, '2021/9/1', 'CS07', 'D04', '000000'),
  ('202106061105', '沈安澜', '女', 21, '山西省太原市', 113, '2021/9/1', 'CS08', 'D05', '000000'),
  ('202106061113', '邹恨水', '女', 20, '山西省太原市', 113, '2021/9/1', 'CS08', 'D05', '000000'),
  ('202106061115', '熊曼', '女', 21, '山西省太原市', 113, '2021/9/1', 'CS08', 'D05', '000000'),
  ('202106061116', '郝贞观', '男', 20, '北京市海淀区', 106, '2021/9/1', 'CS08', 'D05', '000000'),
  ('202106061121', '孔飞', '男', 20, '北京市海淀区', 106, '2021/9/1', 'CS08', 'D05', '000000'),
  ('202106061125', '白照林', '男', 18, '山西省太原市', 89, '2021/9/1', 'CS08', 'D05', '000000'),
  ('202106060801', '崔去弦', '男', 20, '北京市海淀区', 91, '2021/9/1', 'CS08', 'D05', '000000'),
  ('202106060805', '史川寒', '女', 20, '上海市徐汇区', 90, '2021/9/1', 'CS08', 'D05', '000000'),
  ('202106060806', '顾泓朔', '女', 19, '上海市徐汇区', 91, '2021/9/1', 'CS08', 'D05', '000000'),
  ('202106060817', '周楚秦', '女', 19, '上海市徐汇区', 92, '2021/9/1', 'CS08', 'D05', '000000'),
  ('202106060819', '段世宁', '男', 20, '上海市徐汇区', 93, '2021/9/1', 'CS08', 'D05', '000000'),
  ('202106060821', '汤野', '男', 20, '北京市海淀区', 99, '2021/9/1', 'CS08', 'D05', '000000'),
  ('202106060822', '尹禾', '女', 19, '上海市徐汇区', 97, '2021/9/1', 'CS08', 'D05', '2003silver'),
  ('202106060826', '常萱', '女', 20, '北京市海淀区', 98, '2021/9/1', 'CS08', 'D05', 'xvanxvan');

INSERT INTO cwwz_teacher02
VALUES
  ('T01', '杨梁淮', '男', 44, '讲师', '13587992354', 'lianghuai1977'),
  ('T02', '范宇磊', '男', 45, '副教授', '13587992355', 'catcatcat'),
  ('T03', '江黎', '女', 43, '教授', '13587992356', 'datastruct'),
  ('T04', '陈忘兹', '女', 41, '讲师', '13587992357', 'cwz2003'),
  ('T05', '温家薇', '女', 43, '副教授', '15868972341', 'ahwei520'),
  ('T06', '曾辽远', '男', 45, '教授', '15868972342', 'fuckzuiyouhua'),
  ('T07', '毛佳珐', '女', 44, '教授', '15868972343', 'pythonpython'),
  ('T08', '梅坚平', '男', 42, '副教授', '15868972344', 'data2003'),
  ('T09', '周还泛', '男', 42, '副教授', '13587992358', 'teacherzhou2003'),
  ('T10', '王志初', '男', 44, '教授', '15868972345', 'kingchu111');

INSERT INTO cwwz_course02
VALUES
  ('CO01', '数据结构', 3),
  ('CO02', '计算机网络', 3),
  ('CO03', '数据挖掘', 2),
  ('CO04', '最优化方法', 3),
  ('CO05', '概率论与数理统计', 3),
  ('CO06', '运筹学', 3),
  ('CO07', '高等数学', 3),
  ('CO08', '线性代数', 2),
  ('CO09', '离散数学', 3),
  ('CO10', 'C++程序设计', 3),
  ('CO11', '数据库原理及其应用', 3),
  ('CO12', '计算机组成原理', 3),
  ('CO13', '数值分析', 2),
  ('CO14', 'Python程序设计', 3),
  ('CO15', '算法分析与设计', 3),
  ('CO16', '金融数据挖掘', 3),
  ('CO17', '多元统计分析', 4),
  ('CO18', '高维数据的分析与计算', 2),
  ('CO19', '文本分析与挖掘', 2),
  ('CO20', '机器学习', 2);

INSERT INTO cwwz_teach02
VALUES
  ('CO01', 'T01', 'CS01', '2021/2022(1)'),
  ('CO01', 'T01', 'CS02', '2021/2022(1)'),
  ('CO01', 'T01', 'CS03', '2021/2022(1)'),
  ('CO01', 'T02', 'CS04', '2021/2022(1)'),
  ('CO01', 'T02', 'CS05', '2021/2022(1)'),
  ('CO01', 'T02', 'CS06', '2021/2022(1)'),
  ('CO01', 'T02', 'CS07', '2021/2022(1)'),
  ('CO02', 'T03', 'CS01', '2021/2022(2)'),
  ('CO02', 'T03', 'CS02', '2021/2022(2)'),
  ('CO02', 'T04', 'CS08', '2021/2022(2)'),
  ('CO03', 'T05', 'CS03', '2021/2022(1)'),
  ('CO03', 'T05', 'CS04', '2021/2022(1)'),
  ('CO03', 'T06', 'CS05', '2021/2022(1)'),
  ('CO03', 'T06', 'CS06', '2021/2022(1)'),
  ('CO03', 'T07', 'CS07', '2021/2022(1)'),
  ('CO03', 'T07', 'CS08', '2021/2022(1)'),
  ('CO04', 'T08', 'CS01', '2021/2022(2)'),
  ('CO04', 'T08', 'CS02', '2021/2022(2)'),
  ('CO04', 'T09', 'CS06', '2021/2022(2)'),
  ('CO04', 'T09', 'CS07', '2021/2022(2)'),
  ('CO05', 'T10', 'CS08', '2021/2022(2)'),
  ('CO06', 'T10', 'CS06', '2021/2022(2)'),
  ('CO06', 'T10', 'CS07', '2021/2022(2)'),
  ('CO07', 'T04', 'CS08', '2021/2022(2)'),
  ('CO08', 'T05', 'CS01', '2021/2022(2)'),
  ('CO09', 'T06', 'CS02', '2021/2022(1)'),
  ('CO10', 'T07', 'CS08', '2021/2022(1)');

INSERT INTO cwwz_deptcourse02
VALUES
  ('CO01', 'D01', 'T', '2021/2022(1)'),
  ('CO01', 'D02', 'T', '2021/2022(1)'),
  ('CO01', 'D03', 'T', '2021/2022(1)'),
  ('CO01', 'D04', 'T', '2021/2022(1)'),
  ('CO02', 'D01', 'T', '2021/2022(2)'),
  ('CO02', 'D02', 'T', '2021/2022(2)'),
  ('CO02', 'D05', 'T', '2021/2022(2)'),
  ('CO03', 'D03', 'T', '2021/2022(1)'),
  ('CO03', 'D04', 'T', '2021/2022(1)'),
  ('CO03', 'D05', 'T', '2021/2022(1)'),
  ('CO04', 'D01', 'T', '2021/2022(2)'),
  ('CO04', 'D02', 'T', '2021/2022(2)'),
  ('CO04', 'D04', 'T', '2021/2022(2)'),
  ('CO05', 'D05', 'T', '2022/2023(2)'),
  ('CO06', 'D04', 'T', '2022/2023(2)'),
  ('CO07', 'D05', 'T', '2022/2023(2)'),
  ('CO08', 'D01', 'T', '2022/2023(2)'),
  ('CO09', 'D02', 'T', '2022/2023(1)'),
  ('CO10', 'D05', 'T', '2022/2023(1)'),
  ('CO11', 'D01', 'F', '2022/2023(2)'),
  ('CO12', 'D02', 'F', '2022/2023(2)'),
  ('CO13', 'D03', 'F', '2021/2022(1)'),
  ('CO14', 'D04', 'F', '2021/2022(1)'),
  ('CO15', 'D05', 'F', '2022/2023(2)'),
  ('CO16', 'D01', 'F', '2022/2023(2)'),
  ('CO17', 'D02', 'F', '2022/2023(2)'),
  ('CO18', 'D03', 'F', '2022/2023(1)'),
  ('CO19', 'D04', 'F', '2022/2023(1)'),
  ('CO20', 'D05', 'F', '2022/2023(1)');

INSERT INTO cwwz_report02
VALUES
  ('202106060501', 'CO01', 98, 92, '2021/2022(1)'),
  ('202106060501', 'CO02', 95, 87, '2021/2022(2)'),
  ('202106060501', 'CO04', 90, 92, '2021/2022(2)'),
  ('202106060501', 'CO08', 80, 90, '2021/2022(2)'),
  ('202106060605', 'CO01', 72, 95, '2021/2022(1)'),
  ('202106060605', 'CO02', 80, 97, '2021/2022(2)'),
  ('202106060605', 'CO04', 85, 92, '2021/2022(2)'),
  ('202106060605', 'CO09', 85, 89, '2021/2022(1)'),
  ('202106060721', 'CO01', 67, 93, '2021/2022(1)'),
  ('202106060721', 'CO05', 50, 97, '2021/2022(2)'),
  ('202106060302', 'CO01', 72, 76, '2021/2022(1)'),
  ('202106060302', 'CO03', 84, 96, '2021/2022(1)'),
  ('202106060221', 'CO01', 67, 86, '2021/2022(1)'),
  ('202106060221', 'CO03', 88, 97, '2021/2022(1)'),
  ('202106060212', 'CO01', 60, 88, '2021/2022(1)'),
  ('202106060212', 'CO03', 50, 99, '2021/2022(1)'),
  ('202106060401', 'CO01', 86, 96, '2021/2022(1)'),
  ('202106060401', 'CO03', 85, 97, '2021/2022(1)'),
  ('202106060431', 'CO01', 60, 95, '2021/2022(1)'),
  ('202106060431', 'CO03', 61, 83, '2021/2022(1)'),
  ('202106060431', 'CO04', 67, 94, '2021/2022(2)'),
  ('202106060431', 'CO06', 50, 97, '2021/2022(2)'),
  ('202106060435', 'CO02', 96, 98, '2021/2022(2)'),
  ('202106060435', 'CO03', 97, 95, '2021/2022(1)'),
  ('202106060435', 'CO04', 93, 97, '2021/2022(2)'),
  ('202106060435', 'CO06', 98, 96, '2021/2022(2)'),
  ('202106061113', 'CO02', 83, 90, '2021/2022(2)'),
  ('202106061113', 'CO03', 75, 96, '2021/2022(1)'),
  ('202106061113', 'CO05', 74, 92, '2021/2022(2)'),
  ('202106061113', 'CO07', 91, 91, '2021/2022(2)'),
  ('202106061113', 'CO10', 90, 88, '2021/2022(1)');

INSERT INTO cwwz_admin02
VALUES('猫圣钓', '666666');




#建立视图
CREATE VIEW cwwz_course_score02 AS
SELECT cwwz_report02.cwwz_sno02, cwwz_course02.cwwz_coname02, cwwz_course02.cwwz_cono02, cwwz_report02.cwwz_grade02, cwwz_course02.cwwz_cocredit02, cwwz_report02.cwwz_semester02
  FROM cwwz_report02, cwwz_course02
 WHERE cwwz_report02.cwwz_cono02 = cwwz_course02.cwwz_cono02;

CREATE VIEW cwwz_selected_course02 AS
SELECT cwwz_student02.cwwz_sno02, cwwz_course02.cwwz_coname02, cwwz_course02.cwwz_cono02, cwwz_course02.cwwz_cocredit02
  FROM cwwz_student02, cwwz_course02, cwwz_deptcourse02
 WHERE cwwz_deptcourse02.cwwz_dno02 = cwwz_student02.cwwz_dno02
   AND cwwz_deptcourse02.cwwz_cono02 = cwwz_course02.cwwz_cono02;

CREATE VIEW cwwz_teacher_appraise02 AS
SELECT cwwz_student02.cwwz_sno02, cwwz_course02.cwwz_coname02, cwwz_course02.cwwz_cono02, cwwz_report02.cwwz_appraise02, cwwz_teacher02.cwwz_tname02
  FROM cwwz_student02, cwwz_course02, cwwz_teacher02, cwwz_report02, cwwz_teach02
 WHERE cwwz_student02.cwwz_sno02 = cwwz_report02.cwwz_sno02
   AND cwwz_report02.cwwz_cono02 = cwwz_course02.cwwz_cono02
   AND cwwz_teach02.cwwz_tno02 = cwwz_teacher02.cwwz_tno02
   AND cwwz_teach02.cwwz_cono02 = cwwz_report02.cwwz_cono02
   AND cwwz_teach02.cwwz_csno02 = cwwz_student02.cwwz_csno02;

CREATE VIEW cwwz_teach_course02 AS
SELECT DISTINCT cwwz_teacher02.cwwz_tno02, cwwz_course02.cwwz_coname02, cwwz_course02.cwwz_cono02, cwwz_course02.cwwz_cocredit02, cwwz_teach02.cwwz_semester02
  FROM cwwz_teacher02, cwwz_course02, cwwz_teach02
 WHERE cwwz_teacher02.cwwz_tno02 = cwwz_teach02.cwwz_tno02
   AND cwwz_teach02.cwwz_cono02 = cwwz_course02.cwwz_cono02;

CREATE VIEW cwwz_login_score02 AS
SELECT cwwz_teacher02.cwwz_tno02, cwwz_student02.cwwz_sno02, cwwz_student02.cwwz_sname02, cwwz_course02.cwwz_cono02, cwwz_course02.cwwz_coname02, cwwz_report02.cwwz_grade02
  FROM cwwz_student02, cwwz_teacher02, cwwz_course02, cwwz_report02, cwwz_teach02
 WHERE cwwz_teacher02.cwwz_tno02 = cwwz_teach02.cwwz_tno02
   AND cwwz_teach02.cwwz_csno02 = cwwz_student02.cwwz_csno02
   AND cwwz_report02.cwwz_sno02 = cwwz_student02.cwwz_sno02
   AND cwwz_report02.cwwz_cono02 = cwwz_course02.cwwz_cono02
   AND cwwz_teach02.cwwz_cono02 = cwwz_course02.cwwz_cono02;

#总绩点排名
CREATE VIEW cwwz_student_rank02 AS
SELECT student.cwwz_sno02, student.cwwz_avg_grades02, RANK() OVER (ORDER BY student.cwwz_avg_grades02 DESC) AS cwwz_rank02
FROM (
    SELECT cwwz_student02.cwwz_sno02, 
           SUM((cwwz_report02.cwwz_grade02 - 50) / 10.0 * cwwz_course02.cwwz_cocredit02) / SUM(cwwz_course02.cwwz_cocredit02) AS cwwz_avg_grades02
    FROM cwwz_student02, cwwz_report02, cwwz_course02
    WHERE cwwz_report02.cwwz_grade02 >= 60
      AND cwwz_student02.cwwz_sno02 = cwwz_report02.cwwz_sno02
      AND cwwz_report02.cwwz_cono02 = cwwz_course02.cwwz_cono02
    GROUP BY cwwz_student02.cwwz_sno02
) AS student
ORDER BY student.cwwz_avg_grades02;


#绩点学期排名
CREATE VIEW cwwz_student_semester_rank02 AS
SELECT result.cwwz_sno02, result.cwwz_avg_grades02, result.cwwz_semester02, 
       RANK() OVER (PARTITION BY result.cwwz_semester02 ORDER BY result.cwwz_avg_grades02 DESC) AS cwwz_rank02
FROM (
    SELECT student.cwwz_sno02, student.cwwz_avg_grades02, student.cwwz_semester02
    FROM (
        SELECT cwwz_student02.cwwz_sno02, 
               SUM((cwwz_report02.cwwz_grade02 - 50) / 10.0 * cwwz_course02.cwwz_cocredit02) / SUM(cwwz_course02.cwwz_cocredit02) AS cwwz_avg_grades02,
               cwwz_report02.cwwz_semester02
        FROM cwwz_student02, cwwz_report02, cwwz_course02
        WHERE cwwz_report02.cwwz_grade02 >= 60
          AND cwwz_student02.cwwz_sno02 = cwwz_report02.cwwz_sno02
          AND cwwz_report02.cwwz_cono02 = cwwz_course02.cwwz_cono02
        GROUP BY cwwz_student02.cwwz_sno02, cwwz_report02.cwwz_semester02
    ) AS student
) AS result
ORDER BY result.cwwz_semester02, cwwz_rank02;


CREATE VIEW cwwz_choose_course02 AS
SELECT cwwz_student02.cwwz_sno02, cwwz_course02.cwwz_coname02, cwwz_course02.cwwz_cono02, cwwz_course02.cwwz_cocredit02, cwwz_deptcourse02.cwwz_semester02
  FROM cwwz_student02, cwwz_course02, cwwz_deptcourse02
 WHERE cwwz_student02.cwwz_dno02 = cwwz_deptcourse02.cwwz_dno02
   AND cwwz_deptcourse02.cwwz_cono02 = cwwz_course02.cwwz_cono02
   AND cwwz_deptcourse02.cwwz_optional02 = 'T';


CREATE VIEW cwwz_exit_course02 AS
SELECT cwwz_student02.cwwz_sno02, cwwz_course02.cwwz_coname02, cwwz_course02.cwwz_cono02, cwwz_course02.cwwz_cocredit02, cwwz_deptcourse02.cwwz_semester02
  FROM cwwz_student02, cwwz_course02, cwwz_deptcourse02, cwwz_report02
 WHERE cwwz_student02.cwwz_dno02 = cwwz_deptcourse02.cwwz_dno02
   AND cwwz_deptcourse02.cwwz_cono02 = cwwz_course02.cwwz_cono02
   AND cwwz_report02.cwwz_sno02 = cwwz_student02.cwwz_sno02
   AND cwwz_report02.cwwz_cono02 = cwwz_course02.cwwz_cono02
   AND cwwz_report02.cwwz_grade02 IS NULL;


#建立索引
CREATE UNIQUE INDEX index_dept on cwwz_dept02(cwwz_dno02);
CREATE UNIQUE INDEX index_class on cwwz_class02(cwwz_csno02);
CREATE UNIQUE INDEX index_student on cwwz_student02(cwwz_sno02);
CREATE UNIQUE INDEX index_course on cwwz_course02(cwwz_cono02);
CREATE UNIQUE INDEX index_teacher on cwwz_teacher02(cwwz_tno02);

#建立触发器

-- 删除现有触发器
DROP TRIGGER IF EXISTS cwwz_report02_update_trigger;
DROP TRIGGER IF EXISTS cwwz_report02_delete_trigger;

-- 创建触发器
DELIMITER //

CREATE TRIGGER cwwz_report02_update_trigger
AFTER INSERT ON cwwz_report02
FOR EACH ROW 
BEGIN
    UPDATE cwwz_student02 SET cwwz_credits02 = cwwz_credits02 + (SELECT cwwz_cocredit02 FROM cwwz_course02 
    WHERE cwwz_course02.cwwz_cono02 = NEW.cwwz_cono02) 
    WHERE NEW.cwwz_grade02 >= 60 AND cwwz_student02.cwwz_sno02 = NEW.cwwz_sno02;
END //


CREATE TRIGGER cwwz_report02_delete_trigger
AFTER DELETE ON cwwz_report02
FOR EACH ROW
BEGIN
    UPDATE cwwz_student02 SET cwwz_credits02 = cwwz_credits02 - (SELECT cwwz_cocredit02 FROM cwwz_course02 
    WHERE cwwz_course02.cwwz_cono02 = OLD.cwwz_cono02) WHERE OLD.cwwz_grade02 >= 60 AND cwwz_student02.cwwz_sno02 = OLD.cwwz_sno02;
END //

DELIMITER ;




#建存储过程
DELIMITER //

CREATE PROCEDURE sp_delete_graduate(IN end_date DATE, IN min_credit INT)
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE stu_sno VARCHAR(12);

    DECLARE cur CURSOR FOR
    SELECT cwwz_sno02 FROM cwwz_student02
    WHERE cwwz_startdate02 <= DATE_SUB(end_date, INTERVAL 4 YEAR) AND cwwz_credits02 >= min_credit;

    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

    OPEN cur;

    repeat_loop: LOOP
        FETCH cur INTO stu_sno;
        IF done THEN
            LEAVE repeat_loop;
        END IF;

        DELETE FROM cwwz_report02 WHERE cwwz_sno02 = stu_sno;
        DELETE FROM cwwz_student02 WHERE cwwz_sno02 = stu_sno;
    END LOOP;

    CLOSE cur;
END //

DELIMITER ;


DELIMITER //

CREATE PROCEDURE credits_update(IN selected_dno VARCHAR(10), IN new_credits INT)
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE stu_sno VARCHAR(12);

    DECLARE cur CURSOR FOR
    SELECT cwwz_sno02 FROM cwwz_student02 WHERE cwwz_dno02 = selected_dno;

    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

    OPEN cur;

    repeat_loop: LOOP
        FETCH cur INTO stu_sno;
        IF done THEN
            LEAVE repeat_loop;
        END IF;

        UPDATE cwwz_student02 SET cwwz_credits02 = cwwz_credits02 + new_credits WHERE cwwz_sno02 = stu_sno;
    END LOOP;

    CLOSE cur;
END //

DELIMITER ;



SELECT cwwz_sno02 FROM cwwz_student02 WHERE cwwz_dno02 = 'D01';
