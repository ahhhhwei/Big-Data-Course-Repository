package studentdemo;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

public class CourseScheduleManager implements FocusListener {
	DefaultTableModel tableModel;		// Ĭ����ʾ�ı���
	JButton btnAdd,btnDelete,btnCancel,btnChange;  // ��������ť
	JTable table;  // ����
	JFrame f= new JFrame();
	JPanel panelUP;	//������Ϣ�����
	JLabel laCono, laTno, laCsno, laSemster;
	JTextField txtCono, txtTno, txtCsno;
	JComboBox<String> cmbSemester;
	mySQLDriver con=null;
	public CourseScheduleManager(){
		f.setBounds(500, 200, 750, 500);		// ���ô����С
		f.setTitle("������Ϣ���봰��");		// ���ô�������
		f.setLayout(null);
		// �½�����ť���
		btnAdd = new JButton("����");
		btnAdd.setFont(new Font("����С����_GBK", Font.PLAIN, 15));
		btnDelete = new JButton("ɾ��");
		btnDelete.setBounds(240,400,66,26);
		btnDelete.setFont(new Font("����С����_GBK", Font.PLAIN, 15));
		btnChange = new JButton("����");
		btnChange.setBounds(320,400,66,26);
		btnChange.setFont(new Font("����С����_GBK", Font.PLAIN, 15));
		btnCancel = new JButton("�˳�");
		btnCancel.setBounds(400,400,66,26);
		btnCancel.setFont(new Font("����С����_GBK", Font.PLAIN, 15));
		f.add(btnDelete);
		f.add(btnChange);
		f.add(btnCancel);
		panelUP = new JPanel();		// �½���ť������
		panelUP.setLayout(null);
		panelUP.setBounds(92,30,550,150);
		panelUP.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));
		laCono = new JLabel("�γ̺�:");
		laCono.setFont(new Font("����С����_GBK", Font.PLAIN, 13));
		laTno = new JLabel("��ʦ��:");
		laTno.setFont(new Font("����С����_GBK", Font.PLAIN, 13));
		laCsno = new JLabel("�༶��:");
		laCsno.setFont(new Font("����С����_GBK", Font.PLAIN, 13));
		laSemster = new JLabel("�ڿ�ѧ��:");
		laSemster.setFont(new Font("����С����_GBK", Font.PLAIN, 13));

		txtCono = new JTextField();
		txtTno = new JTextField();
		txtCsno = new JTextField();
		cmbSemester = new JComboBox<>();
		cmbSemester.addItem("2022/2023(1)");
		cmbSemester.addItem("2022/2023(2)");
		cmbSemester.addItem("2021/2022(1)");
		cmbSemester.addItem("2021/2022(2)");

		laCono.setBounds(25, 25,80, 12);
		txtCono.setBounds(90, 18, 90, 25);
		laTno.setBounds(200, 25, 80, 12);
		txtTno.setBounds(270, 18, 100,25);

		laCsno.setBounds(25, 80, 85, 15);
		txtCsno.setBounds(90, 78, 90, 25);
		laSemster.setBounds(200, 80, 80, 15);
		cmbSemester.setBounds(270, 78, 100,25);
		btnAdd.setBounds(410,78,66,26);

		panelUP.add(btnAdd);
		panelUP.add(laCono);
		panelUP.add(txtCono);
		panelUP.add(laTno);
		panelUP.add(txtTno);
		panelUP.add(laCsno);
		panelUP.add(txtCsno);
		panelUP.add(laSemster);
		panelUP.add(cmbSemester);

		ResultSet rs = null;
		Vector columnNames = new Vector();
		//��������
		columnNames.add("�γ̺�");
		columnNames.add("��ʦ��");
		columnNames.add("�༶��");
		columnNames.add("�ڿ�ѧ��");
		Vector rowData = new Vector();
		//rowData���Դ�Ŷ���,��ʼ�����ݿ���ȡ
		try {
			rs= con.queryMySQL(con.connectSQL(), "select * FROM cwwz_teach02;");
			if(rs==null) {System.out.print("��ѯ������ ������������");}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			while(rs.next()){
				//rowData���Դ�Ŷ���
				//System.out.print("���� ������������");
				Vector hang=new Vector();
				hang.add(rs.getString(1));
				hang.add(rs.getString(2));
				hang.add(rs.getString(3));
				hang.add(rs.getString(4));
				//���뵽rowData
				rowData.add(hang);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// �½�����
		tableModel = new DefaultTableModel(rowData,columnNames);
		table = new JTable(tableModel) {  //�������ɱ��޸�
			@Override
			public boolean isCellEditable(int row, int column) {
				return false;
			}
		};
		table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		JTableHeader tableHeader=table.getTableHeader();
		tableHeader.setFont(new Font("����С����_GBK", Font.PLAIN, 15));
		table.setFont(new Font("����С����_GBK", Font.PLAIN, 12));
		JScrollPane s = new JScrollPane(table);
		s.setBounds(92, 200, 550, 150);
		f.add(panelUP);
		f.add(s);
		// �¼�����
		MyEvent();
		f.setVisible(true);		// ��ʾ����
	}
	// �¼�����
	public void MyEvent(){
		// ����
		btnAdd.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent arg0) {
				String sql = null;
				int a;

				sql = "insert into cwwz_teach02 values( '" + txtCono.getText() + "','" + txtTno.getText() + "','"
						+ txtCsno.getText() + "','" + cmbSemester.getSelectedItem() +"');";
				a= con.execMySQL(con.connectSQL(), sql);
				if(a>0) {
					tableModel.addRow(new Object[] {txtCono.getText(), txtTno.getText(), txtCsno.getText(), cmbSemester.getSelectedItem()});
					txtCono.setText("");
					txtTno.setText("");
					txtCsno.setText("");
					cmbSemester.setDefaultLocale(null);
				}
			}
		});
		// ɾ��
		btnDelete.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				// ɾ��ָ����
				int rowcount = table.getSelectedRow();
				int rscount;
				if(rowcount==-1) {
					JOptionPane.showMessageDialog(null, "��ѡ������!","��ʾ��Ϣ",JOptionPane.WARNING_MESSAGE);
				}
				String sql="delete from cwwz_teach02 where cwwz_cono02='" + table.getValueAt(rowcount, 0)
						+ "' and cwwz_tno02='" + table.getValueAt(rowcount, 1) + "' and cwwz_csno02='" + table.getValueAt(rowcount, 2)
						+ "' and cwwz_semester02='" + table.getValueAt(rowcount, 3) + "';";
				rscount=con.execMySQL(con.connectSQL(), sql);
				if(rscount>0)
					tableModel.removeRow(rowcount);
			}
		});
		//�޸ı���
		btnChange.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {
				int rowcount = table.getSelectedRow();
				int rscount;
				if(rowcount==-1) {
					JOptionPane.showMessageDialog(null, "��ѡ������!","��ʾ��Ϣ",JOptionPane.WARNING_MESSAGE);
				}

				String sql="update cwwz_deptcourse02 set cwwz_optional02='" + table.getValueAt(rowcount, 2)
						+"' where cwwz_cono02 = '" + table.getValueAt(rowcount, 0)+ "' and cwwz_dno02 = '" + table.getValueAt(rowcount, 1) + "' and cwwz_semester02='" + table.getValueAt(rowcount, 3) + "';";
				con.execMySQL(con.connectSQL(), sql);
			}
		});
		// �˳�
		btnCancel.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				f.dispose();
			}
		});
	}
	// ������
	public static void main(String[] args){
		new CourseScheduleManager();
	}
	@Override
	public void focusGained(FocusEvent e) {
		// TODO Auto-generated method stub
		cmbSemester.setFont(new Font("����С����_GBK", Font.PLAIN, 13));
		cmbSemester.setForeground(Color.BLACK);
	}
	@Override
	public void focusLost(FocusEvent e) {
		// TODO Auto-generated method stub
	}
}
