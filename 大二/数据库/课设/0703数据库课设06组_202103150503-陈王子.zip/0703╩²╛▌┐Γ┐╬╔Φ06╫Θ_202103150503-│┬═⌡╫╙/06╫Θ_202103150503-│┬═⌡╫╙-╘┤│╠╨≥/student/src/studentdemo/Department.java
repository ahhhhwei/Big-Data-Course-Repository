package studentdemo;
public class Department {
	private String dpname;
	private String dpnber;
    public Department(String a, String b){
    	dpname=b;
    	dpnber=a;
    }
    public String toString(){
           return dpname;
    }
    public String toNber(){
        return dpnber;
 }
}