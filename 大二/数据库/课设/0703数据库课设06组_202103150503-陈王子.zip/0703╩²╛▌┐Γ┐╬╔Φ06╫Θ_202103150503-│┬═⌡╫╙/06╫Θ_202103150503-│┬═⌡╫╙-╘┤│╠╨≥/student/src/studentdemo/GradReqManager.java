package studentdemo;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
public class GradReqManager implements FocusListener {
	JLabel laDate,laCrdit;
	JTextField txtDate,txtCredit;
	JFrame f= new JFrame("��ҵ��������");
	JButton btnDelete,btnCancel;
	mySQLDriver con=null;
	public GradReqManager() {
		laDate = new JLabel("��      ��:");
		laDate.setFont(new Font("����С����_GBK", Font.PLAIN, 13));
		laCrdit = new JLabel("��Сѧ��:");
		laCrdit.setFont(new Font("����С����_GBK", Font.PLAIN, 13));
		txtDate = new JTextField("yyyy-mm-dd");
		txtDate.addFocusListener(this);
		txtCredit = new JTextField();
		laDate.setBounds(95, 90,80, 35);
		laCrdit.setBounds(95, 130, 80, 35);
		txtDate.setBounds(163, 93, 165, 30);
		txtCredit.setBounds(163, 133, 165, 30);
		btnDelete = new JButton("ɾ��");
		btnDelete.setFont(new Font("����С����_GBK", Font.PLAIN, 15));
		btnDelete.setBounds(155, 200, 80, 40);
		setJButton(btnDelete);
		btnCancel = new JButton("ȡ��");
		btnCancel.setFont(new Font("����С����_GBK", Font.PLAIN, 15));
		btnCancel.setBounds(240, 200, 80, 40);
		setJButton(btnCancel);
		f.setLayout(null);
		f.add(laDate);
		f.add(laCrdit);
		f.add(txtDate);
		f.add(txtCredit);
		f.add(btnDelete);
		f.add(btnCancel);
		f.setSize(450,350);
		f.setLocationRelativeTo(null);
		f.setVisible(true);
		f.setResizable(false);
		f.setFocusable(true);
		MyEvent(); 
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new GradReqManager();
	}
	/*
	 * ���ð�ť���͸�� 
	 */
	private void setJButton(JButton btn) {  
		btn.setBackground(new Color(102, 0, 204));
		btn.setFont(new Font("����С����_GBK", Font.BOLD, 20));
		btn.setOpaque(false);  
		btn.setBorder(BorderFactory.createEmptyBorder());  
		
	}		
	public void MyEvent(){
		// ɾ��
		btnDelete.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				// ɾ��ָ����
				int cscount;
				int grade=Integer.parseInt(txtCredit.getText().toString());
				String datetime=txtDate.getText();
				if(grade>200|grade < 0) {
					JOptionPane.showMessageDialog(null, "������Ϊ0��200֮�������!","��ʾ��Ϣ",JOptionPane.WARNING_MESSAGE);
					txtCredit.setText("");
				}
			    if(grade>=0 & grade <= 200) {
					cscount=con.execDeleteGraduate(con.connectSQL(), txtDate.getText(), grade);
					if(cscount>0) {
					    txtCredit.setText("");
					    txtDate.setText("");
					  JOptionPane.showMessageDialog(null, "ɾ���ɹ�!","��ʾ��Ϣ",JOptionPane.WARNING_MESSAGE);
					}else {
					   JOptionPane.showMessageDialog(null, "������ô����!","��ʾ��Ϣ",JOptionPane.WARNING_MESSAGE);
					}
				}				
		    	}
		});
		btnCancel.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			
			f.dispose();
			}	
		});
	}
	@Override
	public void focusGained(FocusEvent e) {
		// TODO Auto-generated method stub
		txtDate.setText("");
	}
	@Override
	public void focusLost(FocusEvent e) {
		// TODO Auto-generated method stub
	}
}