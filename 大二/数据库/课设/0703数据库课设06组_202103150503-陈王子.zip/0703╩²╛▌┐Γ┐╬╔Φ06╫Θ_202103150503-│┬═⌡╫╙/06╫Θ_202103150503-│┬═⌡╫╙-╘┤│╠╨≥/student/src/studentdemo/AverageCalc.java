package studentdemo;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

public class AverageCalc {
    JFrame f= new JFrame();
    JPanel jpAverage;
    //ѡ��3 רҵ��ѡ��
    mySQLDriver con;
    DefaultTableModel tableModelAvg;
    JTable tableAvg;
    public AverageCalc(){
        ResultSet rs=null;
        mySQLDriver con=null;
        f.setFont(new Font("����С����_GBK", Font.PLAIN, 15));
        f.setBounds(500, 200, 750, 400);		// ���ô����С
        f.setTitle("ÿ�ſγ�ƽ���ɼ�չʾ����");		// ���ô�������
        f.setLayout(null);
        jpAverage=new JPanel();
        jpAverage.setFont(new Font("����С����_GBK",Font.PLAIN, 10));
        Vector columnNamesCourse = new Vector();
        Vector rowDataCourse= new Vector();
        columnNamesCourse.add("�γ���");
        columnNamesCourse.add("ƽ����");
        try{
            rs= con.queryMySQL(con.connectSQL(), "SELECT cwwz_coname02, AVG(cwwz_grade02) AS average_grade FROM cwwz_report02 INNER JOIN cwwz_course02 ON cwwz_report02.cwwz_cono02 = cwwz_course02.cwwz_cono02 GROUP BY cwwz_coname02;");
            if(rs==null) {System.out.print("�γ�ƽ���ֲ�ѯ�����ݣ�");}
        }catch(
                SQLException e1){
            e1.printStackTrace();
        }
        try {
            while(rs.next()){
                //rowData���Դ�Ŷ���
                System.out.print("�������ݣ�");
                Vector han=new Vector();
                han.add(rs.getString(1));
                han.add(rs.getString(2));
                rowDataCourse.add(han);
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        tableModelAvg=new DefaultTableModel(rowDataCourse,columnNamesCourse);
        tableAvg = new JTable(tableModelAvg) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        JTableHeader tableAvgHeader=tableAvg.getTableHeader();
        tableAvgHeader.setFont(new Font("����С����_GBK", Font.PLAIN, 15));
        tableAvg.setFont(new Font("����С����_GBK", Font.PLAIN, 12));
        tableAvg.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tableAvg.setRowHeight(20);
        DefaultTableCellRenderer tableRender=new DefaultTableCellRenderer();
        tableRender.setHorizontalAlignment(JLabel.CENTER);  //����������
        tableAvg.setDefaultRenderer(Object.class, tableRender);

        JScrollPane s = new JScrollPane(tableAvg);
        s.setBounds(92, 100, 600, 200);
        f.add(s);
        f.setVisible(true);
    }
}
