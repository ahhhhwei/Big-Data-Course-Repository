package studentdemo;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

public class TeacherMain {
	JFrame f;
	JLabel laOldPwd, laNewPwd;
	JPasswordField txtOldPwd, txtNewPwd;
	JButton btnChangeInfo, btnSave, btnChangePwd;
	JTabbedPane tabbedPane;

	JPanel jpInfo, jpCourInfo, jpCourse, jpPassword;
	DefaultTableModel tableModel, tableModelCourse;
	JTable tableInfo, tableCourScore, tableCourse;
	mySQLDriver con=null;
	TeacherMain(String number) {
		f= new JFrame("��У������Ϣ����ϵͳ-��ʦ�û�");
		f.setSize(800, 600);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setVisible(true);

		//ѡ��1 ������Ϣ
		tabbedPane= new JTabbedPane(); //����һ��ѡ�����
		f.setContentPane(tabbedPane);  //��֮���ӵ�����������

		jpInfo =new JPanel();
		btnChangeInfo = new JButton("�޸�");
		btnChangeInfo.setFont(new Font("����С����_GBK", Font.PLAIN, 15));

		ResultSet rs = null;
		Vector hang=new Vector();
		try {
			rs= con.queryMySQL(con.connectSQL(), "select * from cwwz_teacher02 where cwwz_tno02 = '" + number + "';");
			if(rs==null) {System.out.print("��ѯ������ ������������");}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			while(rs.next()){
				//System.out.print("���� ������������");
				hang.add(rs.getString(1));
				hang.add(rs.getString(2));
				hang.add(rs.getString(3));
				hang.add(rs.getString(4));
				hang.add(rs.getString(5));
				hang.add(rs.getString(6));
				hang.add(rs.getString(7));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		tableInfo = new JTable(6,2){
			public boolean isCellEditable(int row, int column) {
				if(row == 5 && column == 1)
					return true;
				return false;
			}
		};
		JTableHeader tableInfoHeader=tableInfo.getTableHeader();
		tableInfoHeader.setFont(new Font("����С����_GBK", Font.PLAIN, 15));
		tableInfo.setFont(new Font("����С����_GBK", Font.PLAIN, 12));
		tableInfo.setRowHeight(20);
		DefaultTableCellRenderer tableRender=new DefaultTableCellRenderer();
		tableRender.setHorizontalAlignment(JLabel.CENTER);
		tableInfo.setDefaultRenderer(Object.class, tableRender);

		tableInfo.setPreferredSize(new Dimension(500,120));
		tableInfo.setValueAt("��ʦ��", 0, 0);
		tableInfo.setValueAt(hang.get(0), 0, 1);
		tableInfo.setValueAt("����", 1, 0);
		tableInfo.setValueAt(hang.get(1), 1, 1);
		tableInfo.setValueAt("�Ա�", 2, 0);
		tableInfo.setValueAt(hang.get(2), 2, 1);
		tableInfo.setValueAt("����", 3, 0);
		tableInfo.setValueAt(hang.get(3), 3, 1);
		tableInfo.setValueAt("ְ��", 4, 0);
		tableInfo.setValueAt(hang.get(4), 4, 1);
		tableInfo.setValueAt("�绰����", 5, 0);
		tableInfo.setValueAt(hang.get(5), 5, 1);

		jpInfo.add(tableInfo);
		jpInfo.add(btnChangeInfo);
		tabbedPane.addTab("������Ϣ", jpInfo);
		tabbedPane.setFont(new Font("����С����_GBK", Font.PLAIN, 15));



		//ѡ��2 �鿴�ڿ���Ϣ
		jpCourInfo = new JPanel();

		Vector columnNames = new Vector();
		Vector rowData = new Vector();
		//��������
		columnNames.add("�γ���");
		columnNames.add("ѧ��");
		columnNames.add("����ѧ��");

		hang.clear();
		try {
			String sql = "select * from cwwz_teach_course02 where cwwz_tno02 = '" + number + "';";
			rs= con.queryMySQL(con.connectSQL(), sql);
			if(rs==null) {System.out.print("��ѯ������ ������������");}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			while(rs.next()){
				//rowData���Դ�Ŷ���
				Vector han=new Vector();
				han.add(rs.getString(2));
				han.add(rs.getString(4));
				han.add(rs.getString(5));
				rowData.add(han);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//System.out.println(rowData);
		tableModel = new DefaultTableModel(rowData,columnNames);
		tableCourScore = new JTable(tableModel) {
			@Override
			public boolean isCellEditable(int row, int column) {
				return false;
			}
		};
		JTableHeader tableCourScoreHeader=tableCourScore.getTableHeader();
		tableCourScoreHeader.setFont(new Font("����С����_GBK", Font.PLAIN, 15));
		tableCourScore.setFont(new Font("����С����_GBK", Font.PLAIN, 12));

		tableCourScore.setRowHeight(20);
		tableCourScore.setDefaultRenderer(Object.class, tableRender);
		tableCourScore.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		JScrollPane jspCourScore = new JScrollPane(tableCourScore);
		jspCourScore.setBounds(100, 180, 600, 120);  //���ò�ѯ�������

		jpCourInfo.add(jspCourScore);
		tabbedPane.addTab("�鿴�ڿ���Ϣ", jpCourInfo);




		//ѡ��3 �ǼǷ���
		Vector columnNamesCourse = new Vector();
		Vector rowDataCourse= new Vector();
		jpCourse = new JPanel();
		columnNamesCourse.add("ѧ��ѧ��");
		columnNamesCourse.add("ѧ������");
		columnNamesCourse.add("�γ̺�");
		columnNamesCourse.add("�γ���");
		columnNamesCourse.add("�÷�");

		try {
			rs= con.queryMySQL(con.connectSQL(), "select * from cwwz_login_score02 where cwwz_tno02 = '" + number + "';");
			if(rs==null) {System.out.print("��ѯ������ ������������");}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			while(rs.next()){
				//rowData���Դ�Ŷ���
				Vector han=new Vector();
				han.add(rs.getString(2));
				han.add(rs.getString(3));
				han.add(rs.getString(4));
				han.add(rs.getString(5));
				han.add(rs.getString(6));
				rowDataCourse.add(han);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		tableModelCourse = new DefaultTableModel(rowDataCourse,columnNamesCourse);
		tableCourse = new JTable(tableModelCourse) {
			@Override
			public boolean isCellEditable(int row, int column) {
				if(column == 4)
					return true;
				return false;
			}
		};
		JTableHeader tableCourseHeader=tableCourse.getTableHeader();
		tableCourseHeader.setFont(new Font("����С����_GBK", Font.PLAIN, 15));
		tableCourse.setFont(new Font("����С����_GBK", Font.PLAIN, 12));

		tableCourse.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		tableCourse.setRowHeight(20);
		tableCourse.setDefaultRenderer(Object.class, tableRender);

		JScrollPane jspSelectedCourse = new JScrollPane(tableCourse);
		jspSelectedCourse.setBounds(100, 180, 600, 120);  //���ò�ѯ�������
		jpCourse.add(jspSelectedCourse);
		tabbedPane.addTab("�ǼǷ���",jpCourse);

		btnSave = new JButton("����");
		btnSave.setFont(new Font("����С����_GBK", Font.PLAIN, 15));
		btnSave.setBounds(600,320,66,26);

		jpCourse.add(btnSave);



		//ѡ��4 �޸�����
		jpPassword=new JPanel();

		btnChangePwd = new JButton("�޸�");
		btnChangePwd.setFont(new Font("����С����_GBK", Font.PLAIN, 15));
		txtOldPwd = new JPasswordField();
		txtNewPwd = new JPasswordField();
		laNewPwd = new JLabel("������");
		laNewPwd.setFont(new Font("����С����_GBK", Font.PLAIN, 12));
		laOldPwd = new JLabel("������");
		laOldPwd.setFont(new Font("����С����_GBK", Font.PLAIN, 12));

		JScrollPane jspPwd = new JScrollPane();
		jspPwd.setBounds(100, 10, 600, 120);  //���ò�ѯ�������

		jpPassword.setLayout(null);
		jpPassword.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));
		jpPassword.setBounds(0,0,800,800);

		btnChangePwd.setBounds(350,150,66,26);
		jpPassword.add(btnChangePwd);
		laNewPwd.setBounds(280,80,66,26);
		jpPassword.add(laNewPwd);
		laOldPwd.setBounds(280,40,66,26);
		jpPassword.add(laOldPwd);
		txtNewPwd.setBounds(340,80,100,26);
		jpPassword.add(txtNewPwd);
		txtOldPwd.setBounds(340,40,100,26);
		jpPassword.add(txtOldPwd);
		tabbedPane.addTab("�������",jpPassword);
		jpPassword.add(jspPwd);

		tabbedPane.setSelectedIndex(0);
		tabbedPane.setPreferredSize(new Dimension(500,200));

		// �¼�����
		MyEvent(number);
	}

	public void MyEvent(String number){
		btnChangeInfo.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {
				int rowcount = tableInfo.getSelectedRow();
				int rscount;
				String sql = null;
				if(rowcount==-1) {
					JOptionPane.showMessageDialog(null, "��ѡ������!","��ʾ��Ϣ",JOptionPane.WARNING_MESSAGE);
				}
				if(rowcount==5) {
					sql="update cwwz_teacher02 set cwwz_phone02 = '" + tableInfo.getValueAt(rowcount, 1)+"' where cwwz_teacher02.cwwz_tno02 = '" + number + "';";
				}
				con.execMySQL(con.connectSQL(), sql);
				JOptionPane.showMessageDialog(null, "�޸ĳɹ�","��ʾ��Ϣ",JOptionPane.WARNING_MESSAGE);
			}
		});
		btnSave.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {
				int rowcount = tableCourse.getSelectedRow();
				int rscount;
				if(rowcount==-1) {
					JOptionPane.showMessageDialog(null, "��ѡ������!","��ʾ��Ϣ",JOptionPane.WARNING_MESSAGE);
				}else {
					String sql="update cwwz_report02 set cwwz_grade02 = "+tableCourse.getValueAt(rowcount, 4)+" where cwwz_sno02 = " + tableCourse.getValueAt(rowcount, 0) + " and cwwz_cono02 = '"+tableCourse.getValueAt(rowcount, 2)+"';";
					con.execMySQL(con.connectSQL(), sql);
					JOptionPane.showMessageDialog(null, "����ɹ�","��ʾ��Ϣ",JOptionPane.WARNING_MESSAGE);
				}
			}
		});
		btnChangePwd.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {
				String oldPwd = new String(txtOldPwd.getPassword());
				String newPwd = new String(txtNewPwd.getPassword());
				String truePwd = null;
				ResultSet rs;
				mySQLDriver con = null;
				try {  //��ȡ��ȷ����
					rs = con.queryMySQL(con.connectSQL(), "select * FROM cwwz_teacher02 WHERE cwwz_tno02 ='" + number + "';");
					try {
						while(rs.next()){
							truePwd = rs.getString(7);
						}
					} catch (SQLException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				if(!oldPwd.equals(truePwd)) {
					JOptionPane.showMessageDialog(null, "�������ԭ���벻��!","��ʾ��Ϣ",JOptionPane.WARNING_MESSAGE);
				}else{
					String sql = "Update cwwz_teacher02 set cwwz_tpassword02 = '"+ newPwd +"' WHERE cwwz_tno02='"+number+"';";
					con.execMySQL(con.connectSQL(), sql);
					JOptionPane.showMessageDialog(null, "�����޸ĳɹ�!","��ʾ��Ϣ",JOptionPane.WARNING_MESSAGE);
				}
			}
		});
	}

	public static void main(String[] args) {
		new TeacherMain("T01");
	}
}









