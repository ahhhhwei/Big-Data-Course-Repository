package studentdemo;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

public class ScoreManager implements FocusListener{
	DefaultTableModel tableModel;		// Ĭ����ʾ�ı���
	JButton btnAdd,btnDelete,btnCancel,btnChange;		// ��������ť
	JTable table;		// ����
	JFrame f= new JFrame("ϵ����Ϣ���봰��");
	JPanel panelUP;	//������Ϣ�����
	JLabel laSno, laCono, laGrade, laLevel, laSemster;
	JTextField txtSno, txtCono, txtGrade, txtLevel;
	JComboBox<String> cmbSemester;
	mySQLDriver con=null;
	public ScoreManager(){
		f.setBounds(500, 200, 750, 550);		// ���ô����С
		f.setTitle("�ɼ�������Ϣ���봰��");		// ���ô�������
		f.setLayout(null);
		// �½�����ť���
		btnAdd = new JButton("����");
		btnAdd.setFont(new Font("����С����_GBK", Font.PLAIN, 15));
		btnDelete = new JButton("ɾ��");
		btnDelete.setFont(new Font("����С����_GBK", Font.PLAIN, 15));
		btnDelete.setBounds(240,460,66,26);
		btnChange = new JButton("����");
		btnChange.setFont(new Font("����С����_GBK", Font.PLAIN, 15));
		btnChange.setBounds(320,460,66,26);
		btnCancel = new JButton("�˳�");
		btnCancel.setFont(new Font("����С����_GBK", Font.PLAIN, 15));
		btnCancel.setBounds(400,460,66,26);
		f.add(btnDelete);
		f.add(btnChange);
		f.add(btnCancel);
		panelUP = new JPanel();		// �½���ť������
		panelUP.setLayout(null);
		panelUP.setBounds(92,30,550,150);
		panelUP.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));
		laSno = new JLabel("ѧ��:");
		laSno.setFont(new Font("����С����_GBK", Font.PLAIN, 13));
		laCono = new JLabel("�γ̺�:");
		laCono.setFont(new Font("����С����_GBK", Font.PLAIN, 13));
		laGrade = new JLabel("�ɼ�:");
		laGrade.setFont(new Font("����С����_GBK", Font.PLAIN, 13));
		laLevel = new JLabel("����:");
		laLevel.setFont(new Font("����С����_GBK", Font.PLAIN, 13));
		laSemster = new JLabel("ѧ��:");
		laSemster.setFont(new Font("����С����_GBK", Font.PLAIN, 13));

		cmbSemester = new JComboBox<>();
		cmbSemester.addItem("2022/2023(1)");
		cmbSemester.addItem("2022/2023(2)");
		cmbSemester.addItem("2021/2022(1)");
		cmbSemester.addItem("2021/2022(2)");
		cmbSemester.setFont(new Font("����С����_GBK", Font.PLAIN, 12));

		txtSno = new JTextField();
		txtCono = new JTextField();
		txtLevel = new JTextField();
		txtGrade = new JTextField();

		laSno.setBounds(25, 25,80, 12);
		txtSno.setBounds(80, 18, 100, 25);
		laCono.setBounds(200, 25, 80, 12);
		txtCono.setBounds(270, 18, 90,25);

		laGrade.setBounds(25, 70, 85, 25);
		txtGrade.setBounds(80, 68, 100, 25);
		laLevel.setBounds(200, 70, 85,25);
		txtLevel.setBounds(270, 68, 90,25);

		laSemster.setBounds(25, 115, 85, 25);
		cmbSemester.setBounds(80, 113, 100, 25);

		btnAdd.setBounds(400,113,66,26);

		panelUP.add(btnAdd);
		panelUP.add(laSno);
		panelUP.add(txtSno);
		panelUP.add(laCono);
		panelUP.add(txtCono);
		panelUP.add(laGrade);
		panelUP.add(laLevel);
		panelUP.add(txtGrade);
		panelUP.add(laSemster);
		panelUP.add(cmbSemester);
		panelUP.add(txtLevel);

		ResultSet rs = null;
		Vector columnNames = new Vector();
		//��������
		columnNames.add("ѧ��");
		columnNames.add("�γ̺�");
		columnNames.add("�ɼ�");
		columnNames.add("����");
		columnNames.add("ѧ��");
		Vector rowData = new Vector();
		//rowData���Դ�Ŷ���,��ʼ�����ݿ���ȡ
		try {
			rs= con.queryMySQL(con.connectSQL(), "select * FROM cwwz_report02;");
			if(rs==null) {System.out.print("��ѯ������ ������������");}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			while(rs.next()){
				//rowData���Դ�Ŷ���
				//System.out.print("���� ������������");
				Vector hang=new Vector();
				hang.add(rs.getString(1));
				hang.add(rs.getString(2));
				hang.add(rs.getString(3));
				hang.add(rs.getString(4));
				hang.add(rs.getString(5));
				//���뵽rowData
				rowData.add(hang);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// �½�����
		tableModel = new DefaultTableModel(rowData,columnNames);
		table = new JTable(tableModel) {  //�������ɱ��޸�
			@Override
			public boolean isCellEditable(int row, int column) {
				if(column == 0 || column == 1 || column == 4)
					return false;
				else
					return true;
			}
		};
		table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		JTableHeader tableHeader=table.getTableHeader();
		tableHeader.setFont(new Font("����С����_GBK", Font.PLAIN, 15));
		table.setFont(new Font("����С����_GBK", Font.PLAIN, 12));
		JScrollPane s = new JScrollPane(table);
		s.setBounds(92, 200, 550, 250);
		f.add(panelUP);
		f.add(s);
		// �¼�����
		MyEvent();
		f.setVisible(true);		// ��ʾ����
	}
	// �¼�����
	public void MyEvent(){
		// ����
		btnAdd.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent arg0) {
				String sql = null;
				int a;

				sql = "insert into cwwz_report02 values( '" + txtSno.getText() + "','" + txtCono.getText() + "',"
						+ txtGrade.getText() + "," + txtLevel.getText() +",'" + cmbSemester.getSelectedItem() + "');";
				a= con.execMySQL(con.connectSQL(), sql);
				if(a>0) {
					tableModel.addRow(new Object[] {txtSno.getText(), txtCono.getText(), txtGrade.getText(),
							txtLevel.getText(), cmbSemester.getSelectedItem()});
					txtSno.setText("");
					txtCono.setText("");
					txtGrade.setText("");
					txtLevel.setText("");
					cmbSemester.setDefaultLocale(null);
				}
			}
		});
		// ɾ��
		btnDelete.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				// ɾ��ָ����
				int rowcount = table.getSelectedRow();
				int rscount;
				if(rowcount==-1) {
					JOptionPane.showMessageDialog(null, "��ѡ������!","��ʾ��Ϣ",JOptionPane.WARNING_MESSAGE);
				}
				String sql="delete from cwwz_report02 where cwwz_sno02='" + table.getValueAt(rowcount, 0) + "' and cwwz_cono02 = '"
						+ table.getValueAt(rowcount, 1) + "' and cwwz_semester02 = '" + table.getValueAt(rowcount, 4) + "';";
				rscount=con.execMySQL(con.connectSQL(), sql);
				if(rscount>0)
					tableModel.removeRow(rowcount);
			}
		});
		//�޸ı���
		btnChange.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {
				int rowcount = table.getSelectedRow();
				int rscount;
				if(rowcount==-1) {
					JOptionPane.showMessageDialog(null, "��ѡ������!","��ʾ��Ϣ",JOptionPane.WARNING_MESSAGE);
				}

				String sql="update cwwz_report02 set cwwz_grade02='" + table.getValueAt(rowcount, 2)+"',cwwz_appraise02='"+ table.getValueAt(rowcount, 3)
						+"' where cwwz_sno02='" + table.getValueAt(rowcount, 0) + "' and cwwz_cono02 = '"
						+ table.getValueAt(rowcount, 1) + "' and cwwz_semester02 = '" + table.getValueAt(rowcount, 4) + "';";
				con.execMySQL(con.connectSQL(), sql);
			}
		});
		// �˳�
		btnCancel.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				f.dispose();
			}
		});
	}
	// ������
	public static void main(String[] args){
		new ScoreManager();
	}
	@Override
	public void focusGained(FocusEvent e) {
		// TODO Auto-generated method stub
		txtGrade.setText("");
		txtGrade.setFont(new Font("����С����_GBK", Font.PLAIN, 13));
		txtGrade.setForeground(Color.BLACK);
	}
	@Override
	public void focusLost(FocusEvent e) {
		// TODO Auto-generated method stub
	}

}
