package studentdemo;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.*;
import javax.swing.JTabbedPane;


public class LoginMain extends JFrame implements ActionListener{
    JLabel laName, laPwd, laLogo;
    JTextField txtName, txtStuName, txtTeaName, txtAdminName;
    JPasswordField txtPwd, txtStuPwd, txtTeaPwd, txtAdminPwd;
    JButton btnLogin,btnExit;
    JPanel jpStu, jpTea, jpAdmin;
    JTabbedPane jtpUser;

    public LoginMain(){
        String []name = new String[]{"ѧ��","��ʦ","����Ա"};
        this.setTitle("��ӭʹ�Ø�����ѧ����ϵͳ");
        txtName = new JTextField();
        txtStuName = new JTextField();  //�˴��ɼ������ı�
        txtTeaName = new JTextField();
        txtAdminName = new JTextField();

        txtPwd = new JPasswordField();
        txtStuPwd = new JPasswordField();
        txtTeaPwd = new JPasswordField();
        txtAdminPwd = new JPasswordField();

        txtStuName.setBounds(163, 118, 165, 30);
        txtTeaName.setBounds(163, 118, 165, 30);
        txtAdminName.setBounds(163, 118, 165, 30);
        txtStuPwd.setBounds(163, 158, 165, 30);
        txtTeaPwd.setBounds(163, 158, 165, 30);
        txtAdminPwd.setBounds(163, 158, 165, 30);

        for(int i=0;i<3;i++) Build(name[i]);
        jtpUser = new JTabbedPane();
        jtpUser.setFont(new Font("����С����_GBK", Font.PLAIN, 15));
        jtpUser.add("ѧ����¼", jpStu);
        jtpUser.add("��ʦ��¼", jpTea);
        jtpUser.add("����Ա��¼", jpAdmin);

        this.setContentPane(jtpUser);
        this.setSize(450,350);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
        this.setResizable(false);
    }

    public void Build(String name){
        laName = new JLabel(name+"��");
        laName.setFont(new Font("����С����_GBK", Font.PLAIN, 15));
        laPwd = new JLabel("��    ��");
        laPwd.setFont(new Font("����С����_GBK", Font.PLAIN, 15));
        laName.setBounds(85, 115,80, 35);
        laPwd.setBounds(85, 155, 80, 35);

        btnLogin = new JButton("��¼");
        btnLogin.setBounds(140, 225, 80, 40);
        setJButton(btnLogin);
        btnExit = new JButton("ȡ��");
        btnExit.setBounds(225, 225, 80, 40);
        setJButton(btnExit);
        btnLogin.addActionListener(this);
        btnExit.addActionListener(this);

        ImageIcon image = new ImageIcon("img/dai.png");
        laLogo = new JLabel("��У�������ϵͳ");  //��ǩ
        laLogo.setFont(new Font("����С����_GBK", Font.PLAIN, 30));
        image.setImage(image.getImage().getScaledInstance(100,100,Image.SCALE_AREA_AVERAGING));
        laLogo.setIcon(image);  //��ͼƬ���ڱ�ǩ��
        laLogo.setBounds(10,10,450, 100);  //���ñ�ǩλ�ô�С

        if(name.equals("ѧ��")) {
            jpStu = new JPanel();
            jpStu.setLayout(null);
            jpStu.add(laLogo);
            jpStu.add(laName);
            jpStu.add(txtStuName);
            jpStu.add(laPwd);
            jpStu.add(txtStuPwd);
            jpStu.add(btnLogin);
            jpStu.add(btnExit);
        } else if (name.equals("��ʦ")) {
            jpTea = new JPanel();
            jpTea.setLayout(null);
            jpTea.add(laLogo);
            jpTea.add(laName);
            jpTea.add(txtTeaName);
            jpTea.add(laPwd);
            jpTea.add(txtTeaPwd);
            jpTea.add(btnLogin);
            jpTea.add(btnExit);
        } else {
            jpAdmin = new JPanel();
            jpAdmin.setLayout(null);
            jpAdmin.add(laLogo);
            jpAdmin.add(laName);
            jpAdmin.add(txtAdminName);
            jpAdmin.add(laPwd);
            jpAdmin.add(txtAdminPwd);
            jpAdmin.add(btnLogin);
            jpAdmin.add(btnExit);
        }
    }

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        new LoginMain();
    }

    private void setJButton(JButton btn) {
        btn.setBackground(new Color(102, 0, 204));// ��ɫ
        btn.setFont(new Font("����С����_GBK", Font.BOLD, 18));
        btn.setOpaque(false);
        btn.setBorder(BorderFactory.createEmptyBorder());
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getActionCommand().equals("ȡ��")) {
            this.dispose();
        }
        if(e.getActionCommand().equals("��¼")) {
            ResultSet rs;
            mySQLDriver con = null;
            String tableName;
            String keyname;
            System.out.println(jtpUser.getSelectedIndex());
            if(jtpUser.getSelectedIndex()==0) {
                System.out.println("cwwz_student02");
                tableName = "cwwz_student02";
                keyname = "cwwz_sno02";
                txtName = txtStuName;
                txtPwd = txtStuPwd;
            }
            else if(jtpUser.getSelectedIndex()==1) {
                System.out.println("cwwz_teacher02");
                tableName = "cwwz_teacher02";
                keyname = "cwwz_tno02";
                txtName = txtTeaName;
                txtPwd = txtTeaPwd;
            }
            else {
                System.out.println("cwwz_admin02");
                tableName = "cwwz_admin02";
                keyname = "cwwz_ano02";
                txtName = txtAdminName;
                txtPwd = txtAdminPwd;
            }

            //System.out.println(txtPwd.);
            String pwd = new String(txtPwd.getPassword());

            if(!txtName.getText().isEmpty() && !pwd.isEmpty()) {
                try {
                    //rs= con.queryMySQL(con.GetCon(), "select * FROM "+tableName+" WHERE "+keyname+"='"+txtName.getText()+"';");
                    rs= con.queryMySQL(con.connectSQL(), "SELECT * FROM "+tableName+" WHERE "+keyname+"='"+txtName.getText()+"';");
                    if(rs==null) {
                        JOptionPane.showMessageDialog(null, "�����ڸ��û���","��ʾ��Ϣ",JOptionPane.WARNING_MESSAGE);
                        clear();
                    }
                    else{
                        try {
                            while(rs.next()){
                                String truePwd;  //��ȡ��ȷ����
                                if(jtpUser.getSelectedIndex()==0){
                                    truePwd = rs.getString(10);
                                }else if(jtpUser.getSelectedIndex()==1){
                                    truePwd = rs.getString(7);
                                }else{
                                    truePwd = rs.getString(2);
                                }
                                if(truePwd.equals(pwd)){
                                    JOptionPane.showMessageDialog(null, "��¼�ɹ�!","��ʾ��Ϣ",JOptionPane.WARNING_MESSAGE);
                                    if(jtpUser.getSelectedIndex()==0){
                                        new StudentMain(txtName.getText());
                                    }else if(jtpUser.getSelectedIndex()==1){
                                        new TeacherMain(txtName.getText());
                                    }else{
                                        new AdminMain();
                                    }
                                    this.setVisible(false);
                                }else {
                                    JOptionPane.showMessageDialog(null, "�������!","��ʾ��Ϣ",JOptionPane.WARNING_MESSAGE);
                                    clear();
                                }
                                return;
                            }
                        } catch (SQLException e2) {
                            // TODO Auto-generated catch block
                            e2.printStackTrace();
                        }
                    }
                    JOptionPane.showMessageDialog(null, "�����ڸ��û���","��ʾ��Ϣ",JOptionPane.WARNING_MESSAGE);
                    clear();
                } catch (SQLException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                }
            }else if(txtName.getText().isEmpty()&&pwd.isEmpty()) {
                JOptionPane.showMessageDialog(null, "�������û���������!","��ʾ��Ϣ",JOptionPane.WARNING_MESSAGE);
                clear();
            }else if(txtName.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "�������û���!","��ʾ��Ϣ",JOptionPane.WARNING_MESSAGE);
                clear();
            }else if(pwd.isEmpty()) {
                JOptionPane.showMessageDialog(null, "����������!","��ʾ��Ϣ",JOptionPane.WARNING_MESSAGE);
                clear();
            }else {
                JOptionPane.showMessageDialog(null, "�û��������������\n����������","��ʾ��Ϣ",JOptionPane.ERROR_MESSAGE);
                clear();
            }
        }
    }

    private void clear() {
        txtName.setText("");
        txtPwd.setText("");
    }
}
