package studentdemo;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

public class StudentMain {
	JFrame f;
	JLabel laOldPwd, laNewPwd;
	JPasswordField txtOldPwd, txtNewPwd;
	JButton btnSave, btnChangePwd, btnChoose, btnExit;
	JTabbedPane tabbedPane;
	JPanel jpInfo, jpCourInfo, jpCourse, jpAppraise, jpPassword, jpRank, jpSemesterRank, jpChoose;
	DefaultTableModel tableModel, tableModelCourse, tableModelAppraise, tableModelRank, tableModelSemesterRank, tableModelChoose;
	JTable tableInfo, tableCourScore, tableCourse, tableAppraise, tableRank, tableSemesterRank, tableChoose;
	Vector rowData, rowDataAppraise;
	mySQLDriver con = null;
	StudentMain(String number) {
		f= new JFrame("����������Ϣ����ϵͳ-ѧ���û�����");
		f.setFont(new Font("����С����_GBK", Font.PLAIN, 20));
		f.setBounds(500, 200, 750, 550);
		f.setLayout(null);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setVisible(true);
		tabbedPane= new JTabbedPane();
		f.setContentPane(tabbedPane);
		tabbedPane.setFont(new Font("����С����_GBK", Font.PLAIN, 15));

		//ѡ��1 �鿴������Ϣ
		jpInfo = new JPanel();

		ResultSet rs = null;
		Vector hang=new Vector();
		try {
			rs= con.queryMySQL(con.connectSQL(), "select * from cwwz_student02 where cwwz_sno02 = '" + number + "';");
			if(rs==null) {System.out.print("��ѯ������ ������������");}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			while(rs.next()){
				hang.add(rs.getString(1));
				hang.add(rs.getString(2));
				hang.add(rs.getString(3));
				hang.add(rs.getString(4));
				hang.add(rs.getString(5));
				hang.add(rs.getString(6));
				hang.add(rs.getString(7).substring(0, 10));
				hang.add(rs.getString(8));
				hang.add(rs.getString(9));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		tableInfo = new JTable(9,2){
			@Override
			public boolean isCellEditable(int row, int column) {
				return false;
			}
		};
		tableInfo.setFont(new Font("����С����_GBK", Font.PLAIN, 12));

		tableInfo.setRowHeight(20);
		DefaultTableCellRenderer tableRender=new DefaultTableCellRenderer();
		tableRender.setHorizontalAlignment(JLabel.CENTER);  //����������
		tableInfo.setDefaultRenderer(Object.class, tableRender);
		tableInfo.setPreferredSize(new Dimension(500,180));

		tableInfo.setValueAt("ѧ��", 0, 0);
		tableInfo.setValueAt(hang.get(0), 0, 1);
		tableInfo.setValueAt("����", 1, 0);
		tableInfo.setValueAt(hang.get(1), 1, 1);
		tableInfo.setValueAt("�Ա�", 2, 0);
		tableInfo.setValueAt(hang.get(2), 2, 1);
		tableInfo.setValueAt("����", 3, 0);
		tableInfo.setValueAt(hang.get(3), 3, 1);
		tableInfo.setValueAt("��Դ��", 4, 0);
		tableInfo.setValueAt(hang.get(4), 4, 1);
		tableInfo.setValueAt("����ѧ��", 5, 0);
		tableInfo.setValueAt(hang.get(5), 5, 1);
		tableInfo.setValueAt("��ѧʱ��", 6, 0);
		tableInfo.setValueAt(hang.get(6), 6, 1);
		tableInfo.setValueAt("�༶��", 7, 0);
		tableInfo.setValueAt(hang.get(7), 7, 1);
		tableInfo.setValueAt("רҵ��", 8, 0);
		tableInfo.setValueAt(hang.get(8), 8, 1);

		jpInfo.add(tableInfo);
		tabbedPane.addTab("�鿴ѧ��������Ϣ", jpInfo);




		//ѡ��2 ��ѡ�μ��˿�
		jpCourInfo = new JPanel();
		btnExit = new JButton("�˿�");
		btnExit.setFont(new Font("����С����_GBK", Font.PLAIN, 15));
		btnExit.setBounds(300,500,66,26);
		Vector columnNames = new Vector();
		rowData = new Vector();
		//��������
		columnNames.add("�γ���");
		columnNames.add("�γ̺�");
		columnNames.add("�÷�");
		columnNames.add("ѧ��");
		columnNames.add("����ѧ��");

		hang.clear();
		try {
			String sql = "select * from cwwz_course_score02 where cwwz_sno02 = '" + number + "';";
			rs= con.queryMySQL(con.connectSQL(), sql);
			if(rs==null) {System.out.print("��ѯ������ ������������");}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			while(rs.next()){
				//rowData���Դ�Ŷ���
				Vector hang1=new Vector();
				hang1.add(rs.getString(2));
				hang1.add(rs.getString(3));
				hang1.add(rs.getString(4));
				hang1.add(rs.getString(5));
				hang1.add(rs.getString(6));
				rowData.add(hang1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		tableModel = new DefaultTableModel(rowData,columnNames);
		tableCourScore = new JTable(tableModel) {
			@Override
			public boolean isCellEditable(int row, int column) {
				return false;
			}
		};
		JTableHeader tableCourScoreHeader = tableCourScore.getTableHeader();
		tableCourScoreHeader.setFont(new Font("����С����_GBK", Font.PLAIN, 15));
		tableCourScore.setRowHeight(20);
		tableCourScore.setFont(new Font("����С����_GBK", Font.PLAIN, 12));
		tableCourScore.setDefaultRenderer(Object.class, tableRender);
		tableCourScore.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		JScrollPane jspCourScore = new JScrollPane(tableCourScore);
		jspCourScore.setBounds(100, 180, 600, 120);  //���ò�ѯ�������

		jpCourInfo.add(jspCourScore);
		jpCourInfo.add(btnExit);
		tabbedPane.addTab("�鿴��ѡ�μ�ѧ���˿�", jpCourInfo);




		//ѡ��3 רҵ��ѡ��
		jpCourse = new JPanel();
		jpCourse.setFont(new Font("����С����_GBK", Font.PLAIN, 10));
		Vector columnNamesCourse = new Vector();
		Vector rowDataCourse= new Vector();
		columnNamesCourse.add("�γ���");
		columnNamesCourse.add("�γ̺�");
		columnNamesCourse.add("ѧ��");

		try {
			rs= con.queryMySQL(con.connectSQL(), "select * from cwwz_selected_course02 where cwwz_sno02 = '" + number + "';");
			if(rs==null) {System.out.print("ѧ���γ̲�ѯ�����ݣ�");}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			while(rs.next()){
				//rowData���Դ�Ŷ���
				Vector han=new Vector();
				han.add(rs.getString(2));
				han.add(rs.getString(3));
				han.add(rs.getString(4));
				rowDataCourse.add(han);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		tableModelCourse = new DefaultTableModel(rowDataCourse,columnNamesCourse);
		tableCourse = new JTable(tableModelCourse) {
			@Override
			public boolean isCellEditable(int row, int column) {
				return false;
			}
		};
		JTableHeader tableCourseHeader=tableCourse.getTableHeader();
		tableCourseHeader.setFont(new Font("����С����_GBK", Font.PLAIN, 15));
		tableCourse.setFont(new Font("����С����_GBK", Font.PLAIN, 12));
		tableCourse.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		tableCourse.setRowHeight(20);
		tableCourse.setDefaultRenderer(Object.class, tableRender);

		JScrollPane jspSelectedCourse = new JScrollPane(tableCourse);
		jspSelectedCourse.setBounds(100, 180, 600, 120);  //���ò�ѯ�������
		jpCourse.add(jspSelectedCourse);
		tabbedPane.addTab("רҵ��ѡ�γ�",jpCourse);




		//ѡ��4 ��������
		jpRank = new JPanel();
		Vector columnNamesRank = new Vector();
		Vector rowDataRank = new Vector();
		//��������
		columnNamesRank.add("�ܼ���");
		columnNamesRank.add("������");

		hang.clear();
		try {
			String sql = "select * from cwwz_student_rank02 where cwwz_sno02 = '" + number + "';";
			rs= con.queryMySQL(con.connectSQL(), sql);
			if(rs==null) {System.out.print("����������ѯ�����ݣ�");}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			while(rs.next()){
				//rowData���Դ�Ŷ���
				Vector han=new Vector();
				han.add(rs.getString(2));//.substring(0,5));
				han.add(rs.getString(3));
				rowDataRank.add(han);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		tableModelRank = new DefaultTableModel(rowDataRank,columnNamesRank);
		tableRank = new JTable(tableModelRank) {
			@Override
			public boolean isCellEditable(int row, int column) {
				return false;
			}
		};
		JTableHeader tableRankHeader=tableRank.getTableHeader();
		tableRankHeader.setFont(new Font("����С����_GBK", Font.PLAIN, 15));
		tableRank.setFont(new Font("����С����_GBK", Font.PLAIN, 12));
		tableRank.setRowHeight(20);
		tableRank.setDefaultRenderer(Object.class, tableRender);
		tableRank.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		JScrollPane jspRank = new JScrollPane(tableRank);
		jspRank.setBounds(100, 180, 600, 120);  //���ò�ѯ�������

		jpRank.add(jspRank);
		tabbedPane.addTab("�鿴�ܼ�������", jpRank);




		//ѡ��5 �鿴ѧ������
		jpSemesterRank = new JPanel();
		Vector columnNamesSemesterRank = new Vector();
		Vector rowDataSemesterRank = new Vector();

		//��������
		columnNamesSemesterRank.add("ѧ��");
		columnNamesSemesterRank.add("����");
		columnNamesSemesterRank.add("����");

		hang.clear();
		try {
			String sql = "select * from cwwz_student_semester_rank02 where cwwz_sno02 = '" + number + "';";
			rs= con.queryMySQL(con.connectSQL(), sql);
			if(rs==null) {System.out.print("ѧ��������ѯ������ ������������");}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			while(rs.next()){
				//rowData���Դ�Ŷ���
				Vector han=new Vector();
				han.add(rs.getString(3));
				han.add(rs.getString(2));//.substring(0,5));
				han.add(rs.getString(4));
				rowDataSemesterRank.add(han);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		tableModelSemesterRank = new DefaultTableModel(rowDataSemesterRank,columnNamesSemesterRank);
		tableSemesterRank = new JTable(tableModelSemesterRank) {
			@Override
			public boolean isCellEditable(int row, int column) {
				return false;
			}
		};
		JTableHeader tableSemesterRankHeader=tableSemesterRank.getTableHeader();
		tableSemesterRankHeader.setFont(new Font("����С����_GBK", Font.PLAIN, 15));
		tableSemesterRank.setFont(new Font("����С����_GBK", Font.PLAIN, 12));
		tableSemesterRank.setRowHeight(20);
		tableSemesterRank.setDefaultRenderer(Object.class, tableRender);
		tableSemesterRank.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		JScrollPane jspSemesterRank = new JScrollPane(tableSemesterRank);
		jspSemesterRank.setBounds(100, 180, 600, 120);  //���ò�ѯ�������

		jpSemesterRank.add(jspSemesterRank);
		tabbedPane.addTab("�鿴ѧ�ڼ�������", jpSemesterRank);




		//ѡ��6 ѡ��
		btnChoose = new JButton("ѡ��");
		btnChoose.setFont(new Font("����С����_GBK", Font.PLAIN, 15));
		jpChoose = new JPanel();		// �½���ť������
		jpChoose.setLayout(null);
		jpChoose.setBounds(92,30,400,150);
		jpChoose.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));

		btnChoose.setBounds(350,88,66,26);
		jpChoose.add(btnChoose);

		Vector columnNamesChoose = new Vector();
		Vector rowDataChoose = new Vector();
		columnNamesChoose.add("�γ���");
		columnNamesChoose.add("�γ̺�");
		columnNamesChoose.add("ѧ��");
		columnNamesChoose.add("����ѧ��");
		//rowData���Դ�Ŷ���,��ʼ�����ݿ���ȡ
		try {
			rs= con.queryMySQL(con.connectSQL(), "select * from cwwz_choose_course02 where cwwz_sno02 = '" + number + "';");
			if(rs==null) {System.out.print("��ѯ������ ������������");}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			while(rs.next()){
				//rowData���Դ�Ŷ���
				hang =new Vector();
				hang.add(rs.getString(2));
				hang.add(rs.getString(3));
				hang.add(rs.getString(4));
				hang.add(rs.getString(5));
				//���뵽rowData
				rowDataChoose.add(hang);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// �½�����
		tableModelChoose = new DefaultTableModel(rowDataChoose,columnNamesChoose);
		tableChoose = new JTable(tableModelChoose) {
			@Override
			public boolean isCellEditable(int row, int column) {
				return false;
			}
		};
		JTableHeader tableChooseHeader=tableChoose.getTableHeader();
		tableChooseHeader.setFont(new Font("����С����_GBK", Font.PLAIN, 15));
		tableChoose.setFont(new Font("����С����_GBK", Font.PLAIN, 12));
		tableChoose.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		JScrollPane jspChoose = new JScrollPane(tableChoose);
		jspChoose.setBounds(92, 170, 600, 120);  //���ò�ѯ�������
		jpChoose.add(jspChoose);
		jpChoose.add(btnChoose);
		tabbedPane.addTab("ѡ��",jpChoose);










		//ѡ��7  ����ʦ�γ�����
		jpAppraise = new JPanel();
		btnSave = new JButton("����");
		btnSave.setFont(new Font("����С����_GBK", Font.PLAIN, 15));
		btnSave.setBounds(600,320,66,26);
		Vector columnNamesAppraise = new Vector();
		rowDataAppraise= new Vector();
		columnNamesAppraise.add("�γ���");
		columnNamesAppraise.add("�γ̺�");
		columnNamesAppraise.add("�γ�����");
		columnNamesAppraise.add("�ο���ʦ");

		rowDataAppraise.clear();
		try {
			rs= con.queryMySQL(con.connectSQL(), "select * from cwwz_teacher_appraise02 where cwwz_sno02 = '" + number + "';");
			if(rs==null) {System.out.print("��ѯ������ ������������");}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			while(rs.next()){
				//rowData���Դ�Ŷ���
				Vector han=new Vector();
				han.add(rs.getString(2));
				han.add(rs.getString(3));
				han.add(rs.getString(4));
				han.add(rs.getString(5));
				rowDataAppraise.add(han);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		tableModelAppraise = new DefaultTableModel(rowDataAppraise,columnNamesAppraise);
		tableAppraise = new JTable(tableModelAppraise) {
			@Override
			public boolean isCellEditable(int row, int column) {
				if(column == 2)
					return true;
				else
					return false;
			}
		};
		JTableHeader tableAppraiseHeader=tableAppraise.getTableHeader();
		tableAppraiseHeader.setFont(new Font("����С����_GBK", Font.PLAIN, 15));
		tableAppraise.setFont(new Font("����С����_GBK", Font.PLAIN, 12));
		tableAppraise.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		tableAppraise.setRowHeight(20);
		tableAppraise.setDefaultRenderer(Object.class, tableRender);

		JScrollPane jspAppraise = new JScrollPane(tableAppraise);
		jspAppraise.setBounds(92, 170, 600, 120);  //���ò�ѯ�������
		jpAppraise.add(jspAppraise);
		jpAppraise.add(btnSave);
		tabbedPane.addTab("��ʦ�γ�����",jpAppraise);




		//8 �޸�����
		jpPassword=new JPanel();

		btnChangePwd = new JButton("�޸�");
		btnChangePwd.setFont(new Font("����С����_GBK", Font.PLAIN, 15));
		txtOldPwd = new JPasswordField();
		txtNewPwd = new JPasswordField();
		laNewPwd = new JLabel("������");
		laNewPwd.setFont(new Font("����С����_GBK", Font.PLAIN, 12));
		laOldPwd = new JLabel("������");
		laOldPwd.setFont(new Font("����С����_GBK", Font.PLAIN, 12));

		JScrollPane jspPwd = new JScrollPane();
		jspPwd.setBounds(100, 10, 600, 120);  //���ò�ѯ�������

		jpPassword.setLayout(null);
		jpPassword.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));
		jpPassword.setBounds(20,20,800,800);

		btnChangePwd.setBounds(350,150,66,26);
		jpPassword.add(btnChangePwd);
		laNewPwd.setBounds(280,80,66,26);
		jpPassword.add(laNewPwd);
		laOldPwd.setBounds(280,40,66,26);
		jpPassword.add(laOldPwd);
		txtNewPwd.setBounds(340,80,100,26);
		jpPassword.add(txtNewPwd);
		txtOldPwd.setBounds(340,40,100,26);
		jpPassword.add(txtOldPwd);
		tabbedPane.addTab("�������",jpPassword);
		jpPassword.add(jspPwd);

		tabbedPane.setSelectedIndex(0);
		tabbedPane.setPreferredSize(new Dimension(500,200));

		// �¼�����
		MyEvent(number);
	}

	public void MyEvent(String number){
		btnSave.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {
				int rowcount = tableAppraise.getSelectedRow();
				int rscount;
				if(rowcount==-1) {
					JOptionPane.showMessageDialog(null, "��ѡ������!","��ʾ��Ϣ",JOptionPane.WARNING_MESSAGE);
				}else{
					String sql="update cwwz_report02 set cwwz_appraise02 = "+tableAppraise.getValueAt(rowcount, 2)+" where cwwz_sno02 = " + number + " and cwwz_cono02 = '"+tableAppraise.getValueAt(rowcount, 1)+"';";
					con.execMySQL(con.connectSQL(), sql);
					JOptionPane.showMessageDialog(null, "����ɹ�","��ʾ��Ϣ",JOptionPane.WARNING_MESSAGE);
				}
			}
		});

		btnChoose.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {
				int rowcount = tableChoose.getSelectedRow();
				int rscount;
				if(rowcount==-1) {
					JOptionPane.showMessageDialog(null, "��ѡ������!","��ʾ��Ϣ",JOptionPane.WARNING_MESSAGE);
				} else {
					String sql="insert into cwwz_report02 values('" + number + "','" + tableChoose.getValueAt(rowcount, 1) + "',"+ null + "," + null + ",'" + tableChoose.getValueAt(rowcount, 3) +"');";
					System.out.println(sql);
					con.execMySQL(con.connectSQL(), sql);
					//JOptionPane.showMessageDialog(null, "�ɹ�","��ʾ��Ϣ",JOptionPane.WARNING_MESSAGE);

					ResultSet rs1 = null;
					try {
						sql = "select * from cwwz_course_score02 where cwwz_sno02 = '" + number + "';";
						rs1= con.queryMySQL(con.connectSQL(), sql);
						if(rs1==null) {System.out.print("��ѯ������ ������������");}
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					try {
						rowData.clear();
						while(rs1.next()){
							//rowData���Դ�Ŷ���
							Vector han=new Vector();
							han.add(rs1.getString(2));
							han.add(rs1.getString(3));
							han.add(rs1.getString(4));
							han.add(rs1.getString(5));
							han.add(rs1.getString(6));
							rowData.add(han);
						}
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					tableCourScore.invalidate();

					try {
						rs1= con.queryMySQL(con.connectSQL(), "select * from cwwz_teacher_appraise02 where cwwz_sno02 = '" + number + "';");
						if(rs1==null) {System.out.print("��ѯ������ ������������");}
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					try {
						rowDataAppraise.clear();
						while(rs1.next()){
							//rowData���Դ�Ŷ���
							Vector han=new Vector();
							han.add(rs1.getString(2));
							han.add(rs1.getString(3));
							han.add(rs1.getString(4));
							han.add(rs1.getString(5));
							rowDataAppraise.add(han);
						}
					} catch (SQLException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					tableAppraise.invalidate();
				}
			}
		});

		btnExit.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {
				int rowcount = tableCourScore.getSelectedRow();
				int rscount;
				if(rowcount==-1) {
					JOptionPane.showMessageDialog(null, "��ѡ������!","��ʾ��Ϣ",JOptionPane.WARNING_MESSAGE);
				}else if(tableCourScore.getValueAt(rowcount, 2) != null){
					JOptionPane.showMessageDialog(null, "���ſ��гɼ�������ɾ��!","��ʾ��Ϣ",JOptionPane.WARNING_MESSAGE);
				} else{
					String sql="delete from cwwz_report02 where cwwz_sno02='" + number + "' and cwwz_cono02 = '" + tableCourScore.getValueAt(rowcount, 1) + "' and cwwz_semester02 = '" + tableCourScore.getValueAt(rowcount, 4) +"';";
					System.out.println(sql);
					con.execMySQL(con.connectSQL(), sql);

					ResultSet rs1 = null;
					try {
						sql = "select * from cwwz_course_score02 where cwwz_sno02 = '" + number + "';";
						rs1= con.queryMySQL(con.connectSQL(), sql);
						if(rs1==null) {System.out.print("��ѯ������ ������������");}
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					try {
						rowData.clear();
						while(rs1.next()){
							//rowData���Դ�Ŷ���
							Vector han=new Vector();
							han.add(rs1.getString(2));
							han.add(rs1.getString(3));
							han.add(rs1.getString(4));
							han.add(rs1.getString(5));
							han.add(rs1.getString(6));
							rowData.add(han);
						}
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					tableCourScore.invalidate();

					try {
						rs1= con.queryMySQL(con.connectSQL(), "select * from cwwz_teacher_appraise02 where cwwz_sno02 = '" + number + "';");
						if(rs1==null) {System.out.print("��ѯ������ ������������");}
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					try {
						rowDataAppraise.clear();
						while(rs1.next()){
							//rowData���Դ�Ŷ���
							Vector han=new Vector();
							han.add(rs1.getString(2));
							han.add(rs1.getString(3));
							han.add(rs1.getString(4));
							han.add(rs1.getString(5));
							rowDataAppraise.add(han);
						}
					} catch (SQLException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					tableAppraise.invalidate();
				}
			}
		});


		btnChangePwd.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {
				String oldPwd = new String(txtOldPwd.getPassword());
				String newPwd = new String(txtNewPwd.getPassword());
				String truePwd = null;
				ResultSet rs;
				mySQLDriver con = null;
				try {  //��ȡ��ȷ����
					rs = con.queryMySQL(con.connectSQL(), "select * FROM cwwz_student02 WHERE cwwz_sno02 ='" + number + "';");
					try {
						while(rs.next()){
							truePwd = rs.getString(10);
						}
					} catch (SQLException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				if(!oldPwd.equals(truePwd)) {
					JOptionPane.showMessageDialog(null, "�������ԭ���벻��!","��ʾ��Ϣ",JOptionPane.WARNING_MESSAGE);
				}else{
					String sql = "Update cwwz_student02 set cwwz_spassword02 = '"+ newPwd +"' WHERE cwwz_sno02 ='"+number+"';";
					con.execMySQL(con.connectSQL(), sql);
					JOptionPane.showMessageDialog(null, "�����޸ĳɹ�!","��ʾ��Ϣ",JOptionPane.WARNING_MESSAGE);
				}
			}
		});
	}

	public static void main(String[] args) {
		new StudentMain("202106060501");
	}
}









