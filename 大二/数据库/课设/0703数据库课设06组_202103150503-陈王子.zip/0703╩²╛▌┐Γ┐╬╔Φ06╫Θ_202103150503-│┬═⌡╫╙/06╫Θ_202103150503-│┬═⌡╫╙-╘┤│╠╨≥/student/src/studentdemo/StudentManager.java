package studentdemo;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;

public class StudentManager implements FocusListener{
	DefaultTableModel tableModel;		// Ĭ����ʾ�ı���
	JButton btnAdd,btnDelete,btnCancel,btnChange;		// ��������ť
	JTable table;		// ����
	JFrame f= new JFrame();
	JPanel panelUP;	//������Ϣ�����
	JLabel laSno,laName,laDept,laTime,laSex,laAge,laSource,laCredits,laClass,laPwd;
	JTextField txtSno,txtName,txtTime,txtAge,txtSource,txtCredits,txtClass,txtPwd;
	JComboBox<Department> cmbDept;
	JComboBox<String> cmbSex;
	mySQLDriver con=null;
	public StudentManager(){
		f.setFont(new Font("����С����_GBK", Font.PLAIN, 15));
		f.setBounds(500, 200, 1200, 550);		// ���ô����С
		f.setTitle("ѧ����Ϣ���봰��");		// ���ô�������
		f.setLayout(null);
		// �½�����ť���
		btnAdd = new JButton("����");
		btnAdd.setFont(new Font("����С����_GBK", Font.PLAIN, 15));

		btnDelete = new JButton("ɾ��");
		btnDelete.setFont(new Font("����С����_GBK", Font.PLAIN, 15));
		btnDelete.setBounds(240,460,66,26);

		btnChange = new JButton("����");
		btnChange.setFont(new Font("����С����_GBK", Font.PLAIN, 15));
		btnChange.setBounds(320,460,66,26);

		btnCancel = new JButton("�˳�");
		btnCancel.setFont(new Font("����С����_GBK", Font.PLAIN, 15));
		btnCancel.setBounds(400,460,66,26);

		f.add(btnDelete);
		f.add(btnChange);
		f.add(btnCancel);

		panelUP = new JPanel();		// �½���ť������
		panelUP.setLayout(null);
		panelUP.setBounds(92,30,1000,250);
		panelUP.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));
		laSno = new JLabel("ѧ��:");
		laSno.setFont(new Font("����С����_GBK", Font.PLAIN, 13));
		laName = new JLabel("����:");
		laName.setFont(new Font("����С����_GBK", Font.PLAIN, 13));
		laSex = new JLabel("�Ա�:");
		laSex.setFont(new Font("����С����_GBK", Font.PLAIN, 13));
		laAge = new JLabel("����:");
		laAge.setFont(new Font("����С����_GBK", Font.PLAIN, 13));
		laSource = new JLabel("��Դ��:");
		laSource.setFont(new Font("����С����_GBK", Font.PLAIN, 13));
		laCredits = new JLabel("����ѧ��:");
		laCredits.setFont(new Font("����С����_GBK", Font.PLAIN, 13));
		laTime = new JLabel("��ѧʱ��:");
		laTime.setFont(new Font("����С����_GBK", Font.PLAIN, 13));
		laDept = new JLabel("ϵ��:");
		laDept.setFont(new Font("����С����_GBK", Font.PLAIN, 13));
		laClass = new JLabel("�༶:");
		laClass.setFont(new Font("����С����_GBK", Font.PLAIN, 13));
		laPwd = new JLabel("����:");
		laPwd.setFont(new Font("����С����_GBK", Font.PLAIN, 13));
		cmbDept=new JComboBox<>();
		cmbDept.setFont(new Font("����С����_GBK", Font.PLAIN, 13));
		ResultSet dp;
		try {
			dp = con.queryDepts(con.connectSQL());  //��ѯרҵ��
			while(dp.next()){
				cmbDept.addItem(new Department(dp.getString(1),dp.getString(2)));
			}
		} catch (SQLException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}

		cmbSex = new JComboBox<>();
		cmbSex.addItem("��");
		cmbSex.addItem("Ů");
		cmbSex.setFont(new Font("����С����_GBK", Font.PLAIN, 12));
		txtSno = new JTextField();
		txtName = new JTextField();
		txtAge = new JTextField();
		txtSource = new JTextField();
		txtCredits = new JTextField();
		txtTime = new JTextField("yyyy-mm-dd");
		txtClass = new JTextField();
		txtPwd = new JTextField();

		txtTime.addFocusListener(this);
		laSno.setBounds(25, 25,40, 12);
		txtSno.setBounds(80, 18, 90, 25);
		laName.setBounds(200, 25, 40, 12);
		txtName.setBounds(270, 18, 90,25);

		laSex.setBounds(25, 70, 85, 25);
		cmbSex.setBounds(80, 68, 90, 25);
		laAge.setBounds(200, 70, 85,25);
		txtAge.setBounds(270, 68, 90,25);

		laSource.setBounds(25, 115, 85, 25);
		txtSource.setBounds(80, 113, 90, 25);
		laCredits.setBounds(200, 115, 85,25);
		txtCredits.setBounds(270, 113, 90,25);

		laDept.setBounds(25, 160, 85, 25);
		cmbDept.setBounds(80, 158, 90, 25);
		laTime.setBounds(200, 160, 85,25);
		txtTime.setBounds(270, 158, 90,25);

		laClass.setBounds(25, 205, 85, 25);
		txtClass.setBounds(80, 203, 90, 25);
		laPwd.setBounds(200, 205, 85,25);
		txtPwd.setBounds(270, 203, 90,25);

		btnAdd.setBounds(400,203,66,26);

		panelUP.add(btnAdd);
		panelUP.add(laSno);
		panelUP.add(txtSno);
		panelUP.add(laName);
		panelUP.add(txtName);
		panelUP.add(laDept);
		panelUP.add(cmbDept);
		panelUP.add(laTime);
		panelUP.add(txtTime);
		panelUP.add(laSex);
		panelUP.add(cmbSex);
		panelUP.add(laAge);
		panelUP.add(txtAge);
		panelUP.add(laSource);
		panelUP.add(txtSource);
		panelUP.add(laCredits);
		panelUP.add(txtCredits);
		panelUP.add(laClass);
		panelUP.add(txtClass);
		panelUP.add(laPwd);
		panelUP.add(txtPwd);

		ResultSet rs = null;
		Vector columnNames = new Vector();
		//��������
		columnNames.add("ѧ��");
		columnNames.add("����");
		columnNames.add("�Ա�");
		columnNames.add("����");
		columnNames.add("��Դ��");
		columnNames.add("����ѧ��");
		columnNames.add("��ѧʱ��");
		columnNames.add("�༶��");
		columnNames.add("רҵ��");
		columnNames.add("����");
		Vector rowData = new Vector();
		//rowData���Դ�Ŷ���,��ʼ�����ݿ���ȡ
		try {
			rs= con.queryMySQL(con.connectSQL(), "select * FROM cwwz_student02;");
			if(rs==null) {System.out.print("��ѯ������ ������������");}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			while(rs.next()){
				//rowData���Դ�Ŷ���
				//System.out.print("���� ������������");
				Vector hang=new Vector();
				hang.add(rs.getString(1));
				hang.add(rs.getString(2));
				hang.add(rs.getString(3));
				hang.add(rs.getString(4));
				hang.add(rs.getString(5));
				hang.add(rs.getString(6));
				hang.add(rs.getString(7).subSequence(0, 10));
				hang.add(rs.getString(8));
				hang.add(rs.getString(9));
				hang.add(rs.getString(10));
				//���뵽rowData
				rowData.add(hang);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// �½�����
		tableModel = new DefaultTableModel(rowData,columnNames);
		table = new JTable(tableModel) {  //��һ�в��ɱ��޸�
			@Override
			public boolean isCellEditable(int row, int column) {
				if(column == 0)
					return false;
				else
					return true;
			}
		};
		table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		JTableHeader tableHeader=table.getTableHeader();
		tableHeader.setFont(new Font("����С����_GBK", Font.PLAIN, 15));
		table.setFont(new Font("����С����_GBK", Font.PLAIN, 12));
		JScrollPane s = new JScrollPane(table);
		s.setBounds(92, 300, 1000, 150);
		f.add(panelUP);
		f.add(s);
		// �¼�����
		MyEvent();
		f.setVisible(true);		// ��ʾ����
	}
	// �¼�����
	public void MyEvent(){
		// ����
		btnAdd.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent arg0) {
				String sql = null;
				int a;
				Department de=(Department)cmbDept.getSelectedItem();

				Map sex = new HashMap();
				sex.put("��","��");
				sex.put("Ů","Ů");

				sql = "insert into cwwz_student02 values( '" + txtSno.getText() + "','"
						+ txtName.getText() + "','"
						+ sex.get(cmbSex.getSelectedItem()) + "','"
						+ txtAge.getText() +"','"
						+ txtSource.getText() + "','"
						+ txtCredits.getText() + "','"
						+ txtTime.getText() + "','"
						+ txtClass.getText() + "','"
						+ de.toNber() + "','"+
						txtPwd.getText() +"');";
				a= con.execMySQL(con.connectSQL(), sql);
				if(a>0) {
					tableModel.addRow(new Object[] {txtSno.getText(), txtName.getText(), sex.get(cmbSex.getSelectedItem()),txtAge.getText(),
							txtSource.getText(), txtCredits.getText(), txtTime.getText(), txtClass.getText(), de.toNber(), txtPwd.getText()});
					txtSno.setText("");
					txtName.setText("");
					txtTime.setText("");
					txtCredits.setText("");
					txtSource.setText("");
					txtAge.setText("");
					txtPwd.setText("");
					txtClass.setText("");
					cmbSex.setDefaultLocale(null);
					cmbDept.setDefaultLocale(null);
				}
			}
		});
		// ɾ��
		btnDelete.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				// ɾ��ָ����
				int rowcount = table.getSelectedRow();
				int rscount;
				if(rowcount==-1) {
					JOptionPane.showMessageDialog(null, "��ѡ������!","��ʾ��Ϣ",JOptionPane.WARNING_MESSAGE);
				}
				String sql="delete from cwwz_student02 where cwwz_sno02='" + table.getValueAt(rowcount, 0)+"';";
				rscount=con.execMySQL(con.connectSQL(), sql);
				if(rscount>0)
					tableModel.removeRow(rowcount);
			}
		});
		//�޸ı���
		btnChange.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {
				int rowcount = table.getSelectedRow();
				int rscount;
				if(rowcount==-1) {
					JOptionPane.showMessageDialog(null, "��ѡ������!","��ʾ��Ϣ",JOptionPane.WARNING_MESSAGE);
				}

				String sql="update cwwz_student02 set cwwz_sname02='" + table.getValueAt(rowcount, 1)+"',cwwz_ssex02='"+ table.getValueAt(rowcount, 2)
						+"',cwwz_sage02='"+table.getValueAt(rowcount, 3)+"',cwwz_source02='"+table.getValueAt(rowcount, 4)
						+"',cwwz_credits02='"+table.getValueAt(rowcount, 5)+"',cwwz_startdate02='"+table.getValueAt(rowcount, 6)
						+"',cwwz_csno02='"+table.getValueAt(rowcount, 7)+"',cwwz_dno02='"+table.getValueAt(rowcount, 8)
						+"',cwwz_spassword02='"+table.getValueAt(rowcount, 9)
						+"'where cwwz_sno02 ='"+table.getValueAt(rowcount, 0) +"';";
				con.execMySQL(con.connectSQL(), sql);
			}
		});
		// �˳�
		btnCancel.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				f.dispose();
			}
		});
	}
	// ������
	public static void main(String[] args){
		new StudentManager();
	}
	@Override
	public void focusGained(FocusEvent e) {
		// TODO Auto-generated method stub
		txtTime.setText("");
		txtTime.setFont(new Font("����С����_GBK", Font.PLAIN, 13));
		txtTime.setForeground(Color.BLACK);
	}
	@Override
	public void focusLost(FocusEvent e) {
		// TODO Auto-generated method stub
	}

}
