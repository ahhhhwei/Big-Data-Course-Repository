package studentdemo;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;

public class DeptCreditManager implements FocusListener {
	JLabel laDno,laCrdit;
	JTextField txtDno,txtCredit;
	JFrame f= new JFrame("����רҵѧ��");
	JButton btnDelete,btnCancel;
	mySQLDriver con=null;
	public DeptCreditManager() {
		laDno = new JLabel("ר  ҵ  ��:");
		laDno.setFont(new Font("����С����_GBK", Font.PLAIN, 13));
		laCrdit = new JLabel("����ѧ��ֵ:");
		laCrdit.setFont(new Font("����С����_GBK", Font.PLAIN, 13));
		txtDno = new JTextField("Dxx");
		txtDno.addFocusListener(this);
		txtCredit = new JTextField();
		laDno.setBounds(85, 90,80, 35);
		laCrdit.setBounds(85, 130, 80, 35);
		txtDno.setBounds(163, 93, 165, 30);
		txtCredit.setBounds(163, 133, 165, 30);
		btnDelete = new JButton("�޸�");
		btnDelete.setBounds(155, 200, 80, 40);
		setJButton(btnDelete);
		btnCancel = new JButton("ȡ��");		
		btnCancel.setBounds(240, 200, 80, 40);
		setJButton(btnCancel);
		f.setLayout(null);
		f.add(laDno);
		f.add(laCrdit);
		f.add(txtDno);
		f.add(txtCredit);
		f.add(btnDelete);
		f.add(btnCancel);
		f.setSize(450,350);
		f.setLocationRelativeTo(null);
		f.setVisible(true);
		f.setResizable(false);
		f.setFocusable(true);
		MyEvent(); 
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new DeptCreditManager();
	}
	/*
	 * ���ð�ť���͸�� 
	 */
	private void setJButton(JButton btn) {  
		btn.setBackground(new Color(102, 0, 204));
		btn.setFont(new Font("����С����_GBK", Font.BOLD, 20));
		btn.setOpaque(false);  
		btn.setBorder(BorderFactory.createEmptyBorder());
	}		
	public void MyEvent(){
		// �޸�
		btnDelete.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				int cscount;
				int grade=Integer.parseInt(txtCredit.getText());
				String datetime= txtDno.getText();
				if(grade>100|grade < -100) {
					JOptionPane.showMessageDialog(null, "������Ϊ-100��100֮�������!","��ʾ��Ϣ",JOptionPane.WARNING_MESSAGE);
					txtCredit.setText("");
				}
			    if(grade >= -100 & grade <= 100) {
					cscount=con.execUpdateCredits(con.connectSQL(), txtDno.getText(), grade);
					if(cscount>0) {
					    txtCredit.setText("");
					    txtDno.setText("");
					  JOptionPane.showMessageDialog(null, "�����ɹ�!","��ʾ��Ϣ",JOptionPane.WARNING_MESSAGE);
					}else {
					   JOptionPane.showMessageDialog(null, "������ô����!","��ʾ��Ϣ",JOptionPane.WARNING_MESSAGE);
					}
				}				
		    	}
		});
		btnCancel.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			
			f.dispose();
			}	
		});
	}
	@Override
	public void focusGained(FocusEvent e) {
		// TODO Auto-generated method stub
		txtDno.setText("");
	}
	@Override
	public void focusLost(FocusEvent e) {
		// TODO Auto-generated method stub
	}
}